# Multi-Agent Data-Driven RCIS: Stages 1-5

This MATLAB project implements the first four reproducible experiments for the
multi-agent data-driven RCIS paper.

Stage 1 provides:

1. a heterogeneous five-vehicle platoon;
2. bounded measurement noise and measured exogenous signals;
3. local one-step data collection;
4. the fixed minimum-norm data-driven predictor
   `x_next_hat = X1 * G * w`;
5. a deterministic residual envelope containing calibration coverage,
   a residual Lipschitz bound, and measurement-noise support;
6. independent held-out validation, assertions, figures, and a CSV summary.

Stage 2 adds:

1. predecessor-following coupling for five heterogeneous vehicles;
2. a front-to-back one-hop certificate message;
3. a distributed data-driven RCIS safety filter;
4. hard input/state and braking-distance constraints;
5. closed-loop recursive-feasibility checks against a nominal baseline.

Stage 3 adds:

1. a lifted data-driven predictor with the additional feature `v*abs(v)`;
2. deterministic propagation of bounded measurement noise through the lift;
3. a robust, tilted ellipsoid in spacing-error/relative-velocity coordinates;
4. an offline tensor-grid existence test for a robust successor input;
5. a one-hop predecessor acceleration contract and a direct
   affine-versus-lifted model comparison for all five agents.

Stage 4 adds:

1. full five-vehicle closed-loop coupling with front-to-back certificate
   messages;
2. bounded online measurement noise;
3. 10% unmodelled drag and predecessor-contract violation stress cases;
4. Monte Carlo comparison against the unfiltered nominal controller;
5. explicit checks of recursive input feasibility, transmitted-interval
   containment, leader-contract compliance, and one-step envelope coverage.

Stage 5 adds:

1. a complete box cover of the continuous ellipsoidal state domain,
   continuous disturbance interval, and predecessor-speed range;
2. interval propagation through the lifted data-driven predictor;
3. adaptive bisection of cells that cannot be certified at the initial
   resolution;
4. a saved piecewise-constant input certificate for every final leaf cell.

No optimization toolbox, Statistics and Machine Learning Toolbox, or YALMIP
is required. MATLAB R2020a or newer is recommended.

## Run

Open MATLAB in this folder and execute:

```matlab
run_stage1_data_validation
```

Run the coupled distributed experiment with:

```matlab
run_stage2_distributed_rcis
```

Run the offline Stage 3 certificate with:

```matlab
run_stage3_offline_rcis
```

Run the coupled Monte Carlo experiment with:

```matlab
run_stage4_monte_carlo
```

Run the continuous-domain interval certificate with:

```matlab
run_stage5_continuous_certificate
```

The repository also includes a GitHub Actions workflow that runs the same
script using the official `matlab-actions/setup-matlab` and
`matlab-actions/run-command` actions. Workflow artifacts are retained for one
day.

Generated files are written to `results/`:

- `stage1_results.mat`
- `stage1_summary.csv`
- `fig_stage1_residual_ratio.png`
- `fig_stage1_data_quality.png`

Stage 2 writes the following files to `results_stage2/`:

- `stage2_results.mat`
- `stage2_method_summary.csv`
- `stage2_agent_summary.csv`
- `fig_stage2_distributed_closed_loop.png`
- `fig_stage2_method_comparison.png`

Stage 3 writes the following files to `results_stage3/`:

- `stage3_results.mat`
- `stage3_grid_summary.csv`
- `fig_stage3_grid_certificate.png`

Stage 4 writes the following files to `results_stage4/`:

- `stage4_results.mat`
- `stage4_trial_summary.csv`
- `stage4_scenario_summary.csv`
- `fig_stage4_monte_carlo.png`

Stage 5 writes the following files to `results_stage5/`:

- `stage5_results.mat`
- `stage5_continuous_summary.csv`
- `fig_stage5_continuous_certificate.png`

## Interpretation

For every tested residual component, the normalized ratio

```matlab
abs(x_next_measured - x_next_predicted) ./ beta
```

must be no larger than one, up to numerical tolerance. The script stops with
an error if the data matrix is rank deficient or if the certified envelope is
violated.

The true vehicle dynamics and its derivative are used only by the simulation
plant and to supply a known residual Lipschitz upper bound. The data-driven
predictor itself uses only the sampled matrices `W` and `X1`.

The Stage 2 filter uses a dense scalar input grid so that the reproducible
experiment remains independent of commercial optimization software. The next
stage can replace this online search with the paper's offline homothetic RCIS
and edge-responsibility contract program.

Stage 3 deliberately distinguishes an offline tensor-grid certificate from a
continuous-state theorem. Every included grid state must have at least one
input whose complete interval-valued successor lies inside the same
ellipsoid. The four vertices of the successor rectangle are checked because
the ellipsoidal quadratic form is convex. A later interval subdivision or
Lipschitz cell argument is still required to promote this result to a
continuous-domain proof.

Stage 4 uses a state-dependent velocity-interval message from each vehicle to
its follower. Under the `Certified` scenario, the leader remains in the
declared reference-speed range and its realized acceleration stays inside the
declared one-step contract. The mismatch scenarios are empirical stress tests,
not part of the Stage 3 certificate. Consequently, successful Stage 4 Monte
Carlo trials support closed-loop robustness claims but do not replace the
missing continuous-domain invariance proof.

Stage 5 attempts to close that gap using a sufficient interval argument. Each
box intersecting the candidate ellipsoid is assigned one grid input. The
complete interval-valued successor of the entire box must lie in the same
ellipsoid for every disturbance and predecessor acceleration allowed by the
declared contract. The script asserts that no leaf cell remains unresolved;
if the assertion passes, the saved cell/input map is a reproducible
continuous-domain certificate relative to the deterministic learned-model
error envelope and the stated operating domain.
