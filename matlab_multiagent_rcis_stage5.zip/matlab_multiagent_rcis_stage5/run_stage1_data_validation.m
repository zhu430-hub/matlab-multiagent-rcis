clear;
clc;
close all;
set(groot, 'defaultFigureVisible', 'off');

projectRoot = fileparts(mfilename('fullpath'));
addpath(fullfile(projectRoot, 'functions'));

cfg = config_stage1(projectRoot);
rng(cfg.randomSeed, 'twister');

fprintf('Multi-agent data-driven RCIS experiment: Stage 1\n');
fprintf('Agents: %d, training samples/agent: %d, test samples/agent: %d\n', ...
    cfg.N, cfg.data.nTrain, cfg.data.nTest);

models = cell(cfg.N, 1);
calibration = cell(cfg.N, 1);
validation = cell(cfg.N, 1);

for i = 1:cfg.N
    fprintf('\nAgent %d/%d\n', i, cfg.N);

    trainingData = collect_training_data(cfg, i);
    models{i} = fit_local_predictor(trainingData, cfg);
    calibration{i} = build_calibration_envelope(models{i}, cfg, i);
    validation{i} = validate_error_envelope( ...
        models{i}, calibration{i}, cfg, i);

    fprintf('  rank(W)             = %d/%d\n', ...
        models{i}.numericalRank, cfg.dim.w);
    fprintf('  sigma_min(W)        = %.4e\n', ...
        models{i}.sigmaMin);
    fprintf('  cond(W)             = %.4e\n', ...
        models{i}.conditionNumber);
    fprintf('  max residual ratio  = %.6f\n', ...
        validation{i}.maxRatio);
    fprintf('  envelope coverage   = %.2f%%\n', ...
        100 * validation{i}.coverageRate);

    assert(models{i}.numericalRank == cfg.dim.w, ...
        'Agent %d data matrix W is rank deficient.', i);
    assert(models{i}.sigmaMin >= cfg.data.sigmaMinRequired, ...
        'Agent %d violates the required numerical rank margin.', i);
    assert(validation{i}.maxRatio <= 1 + cfg.validation.tolerance, ...
        'Agent %d violates the deterministic residual envelope.', i);
end

summary = build_stage1_summary(models, calibration, validation, cfg);

if ~exist(cfg.resultsDir, 'dir')
    mkdir(cfg.resultsDir);
end

save(fullfile(cfg.resultsDir, 'stage1_results.mat'), ...
    'cfg', 'models', 'calibration', 'validation', 'summary');
writetable(summary, fullfile(cfg.resultsDir, 'stage1_summary.csv'));

plot_stage1_results(models, validation, summary, cfg);

fprintf('\nStage 1 completed successfully.\n');
fprintf('Worst normalized residual ratio: %.6f\n', max(summary.MaxResidualRatio));
fprintf('Results folder: %s\n', cfg.resultsDir);
