function plot_stage1_results(models, validation, summary, cfg)
%PLOT_STAGE1_RESULTS Generate paper-development diagnostic figures.

if ~exist(cfg.resultsDir, 'dir')
    mkdir(cfg.resultsDir);
end

colors = lines(cfg.N);

figure('Color', 'w', 'Position', [100, 100, 1050, 720]);
tiledlayout(2, 1, 'Padding', 'compact', 'TileSpacing', 'compact');

stateNames = {'Position-error successor', 'Velocity successor'};
for stateIndex = 1:cfg.dim.x
    nexttile;
    hold on;
    for i = 1:cfg.N
        values = sort(validation{i}.ratio(stateIndex, :));
        empiricalProbability = (1:numel(values)) / numel(values);
        plot(values, empiricalProbability, 'LineWidth', 1.6, ...
            'Color', colors(i, :), ...
            'DisplayName', sprintf('Agent %d', i));
    end
    xline(1, '--r', 'Certified boundary', 'LineWidth', 1.4);
    grid on;
    xlabel('|residual| / \beta');
    ylabel('Empirical cumulative probability');
    title(stateNames{stateIndex});
    xlim([0, 1.05]);
    ylim([0, 1]);
    if stateIndex == 1
        legend('Location', 'northeastoutside');
    end
end

exportgraphics(gcf, ...
    fullfile(cfg.resultsDir, 'fig_stage1_residual_ratio.png'), ...
    'Resolution', 300);

figure('Color', 'w', 'Position', [120, 120, 1050, 420]);
tiledlayout(1, 2, 'Padding', 'compact', 'TileSpacing', 'compact');

nexttile;
semilogy(summary.Agent, summary.SigmaMinW, 'o-', ...
    'LineWidth', 1.6, 'MarkerSize', 7);
grid on;
xlabel('Agent');
ylabel('\sigma_{min}(W_i)');
title('Data-matrix numerical rank margin');

nexttile;
bar(summary.Agent, summary.MaxResidualRatio, 0.65);
hold on;
yline(1, '--r', 'Certified boundary', 'LineWidth', 1.4);
grid on;
xlabel('Agent');
ylabel('Maximum |residual| / \beta');
title('Independent-test envelope validation');
ylim([0, max(1.05, 1.1 * max(summary.MaxResidualRatio))]);

exportgraphics(gcf, ...
    fullfile(cfg.resultsDir, 'fig_stage1_data_quality.png'), ...
    'Resolution', 300);

% Prevent an unused-input warning while keeping models available for future
% figure extensions.
assert(numel(models) == cfg.N);
end
