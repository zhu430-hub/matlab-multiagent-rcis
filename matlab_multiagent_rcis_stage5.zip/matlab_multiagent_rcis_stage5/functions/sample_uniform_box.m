function q = sample_uniform_box(lowerBound, upperBound, sampleCount)
%SAMPLE_UNIFORM_BOX Draw column samples uniformly from a box.

q = lowerBound + (upperBound - lowerBound) .* ...
    rand(numel(lowerBound), sampleCount);
end
