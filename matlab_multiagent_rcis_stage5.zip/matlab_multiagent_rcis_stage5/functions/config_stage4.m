function cfg4 = config_stage4(cfg1, cfg3, projectRoot)
%CONFIG_STAGE4 Coupled Monte Carlo robustness experiment.

cfg4.Tfinal = 8.0;
cfg4.nSteps = round(cfg4.Tfinal / cfg1.Ts);
cfg4.nTrials = 20;
cfg4.filter.uGrid = cfg3.input.uGrid;
cfg4.filter.feasibilityTolerance = 1e-9;

cfg4.nominal.kRelativeVelocity = 0.65;
cfg4.nominal.kSpacing = 0.18;

cfg4.leader.initialVelocity = 4.60;
cfg4.leader.declaredAccelMin = cfg3.operating.aRefMin;
cfg4.leader.declaredAccelMax = cfg3.operating.aRefMax;
cfg4.leader.segmentSteps = 10;

cfg4.initial.errorOffset = [0.10; 0.05; 0.00; -0.05; -0.10];
cfg4.initial.relativeVelocity = [-0.03; 0.02; -0.01; 0.03; 0.00];

names = {'Certified'; 'DragMismatch10'; ...
    'ContractViolation'; 'CombinedStress'};
dragMismatch = [0.00; 0.10; 0.00; 0.10];
leaderActualAccelMax = [0.20; 0.20; 0.25; 0.25];
for i = 1:numel(names)
    cfg4.scenario(i).name = names{i};
    cfg4.scenario(i).dragMismatch = dragMismatch(i);
    cfg4.scenario(i).leaderActualAccelMax = leaderActualAccelMax(i);
end

cfg4.validation.tolerance = 1e-8;
cfg4.resultsDir = fullfile(projectRoot, 'results_stage4');
end
