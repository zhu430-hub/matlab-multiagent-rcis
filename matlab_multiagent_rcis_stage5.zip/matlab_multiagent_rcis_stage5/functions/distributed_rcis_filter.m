function [uFiltered, diagnostics] = distributed_rcis_filter( ...
    q, uNominal, model, envelope, predecessorVelocityLower, cfg1, cfg2)
%DISTRIBUTED_RCIS_FILTER One-hop robust successor input filter.

gridCandidate = evaluate_stage2_candidate( ...
    q, cfg2.filter.uGrid, model, envelope, ...
    predecessorVelocityLower, cfg1, cfg2);
nominalCandidate = evaluate_stage2_candidate( ...
    q, uNominal, model, envelope, ...
    predecessorVelocityLower, cfg1, cfg2);

feasibleIndices = find(gridCandidate.feasible);
recursiveFeasible = ~isempty(feasibleIndices);

if recursiveFeasible
    [~, localIndex] = min( ...
        (cfg2.filter.uGrid(feasibleIndices) - uNominal).^2);
    selectedIndex = feasibleIndices(localIndex);
else
    [~, selectedIndex] = max(gridCandidate.minimumMargin);
end

uFiltered = cfg2.filter.uGrid(selectedIndex);

diagnostics.recursiveFeasible = recursiveFeasible;
diagnostics.feasibleCount = numel(feasibleIndices);
diagnostics.filterActive = ~nominalCandidate.feasible;
diagnostics.nominal = nominalCandidate;
diagnostics.filtered.prediction = ...
    gridCandidate.prediction(:, selectedIndex);
diagnostics.filtered.beta = gridCandidate.beta(:, selectedIndex);
diagnostics.filtered.margins = ...
    gridCandidate.margins(:, selectedIndex);
diagnostics.filtered.minimumMargin = ...
    gridCandidate.minimumMargin(selectedIndex);
end
