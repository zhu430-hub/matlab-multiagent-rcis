function candidate = evaluate_stage2_candidate( ...
    q, uCandidate, model, envelope, predecessorVelocityLower, cfg1, cfg2)
%EVALUATE_STAGE2_CANDIDATE Robust successor margins for candidate inputs.

uCandidate = reshape(uCandidate, 1, []);
qCandidate = repmat(q, 1, numel(uCandidate));
qCandidate(1, :) = uCandidate;

wCandidate = [qCandidate; ones(1, numel(uCandidate))];
prediction = model.M * wCandidate;
beta = evaluate_error_bound(qCandidate, envelope, cfg1);

errorLower = prediction(1, :) - beta(1, :);
errorUpper = prediction(1, :) + beta(1, :);
velocityLower = prediction(2, :) - beta(2, :);
velocityUpper = prediction(2, :) + beta(2, :);

relativeVelocityUpper = max( ...
    velocityUpper - predecessorVelocityLower, 0);
stoppingTerm = relativeVelocityUpper.^2 ./ ...
    (2 * cfg2.rcis.relativeBraking);

margins = [ ...
    errorLower - cfg2.rcis.eMin; ...
    cfg2.rcis.eMax - errorUpper - stoppingTerm; ...
    velocityLower - cfg2.rcis.vMin; ...
    cfg2.rcis.vMax - velocityUpper];

candidate.prediction = prediction;
candidate.beta = beta;
candidate.margins = margins;
candidate.minimumMargin = min(margins, [], 1);
candidate.feasible = all( ...
    margins >= -cfg2.filter.feasibilityTolerance, 1);
end
