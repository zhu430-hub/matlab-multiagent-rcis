function cfg2 = config_stage2(cfg1, projectRoot)
%CONFIG_STAGE2 Coupled closed-loop and distributed RCIS configuration.

cfg2.Tfinal = 12.0;
cfg2.time = 0:cfg1.Ts:cfg2.Tfinal;
cfg2.nSteps = numel(cfg2.time) - 1;

% Inner robust controlled-invariant safety set.
cfg2.rcis.eMin = -3.5;
cfg2.rcis.eMax = 2.0;
cfg2.rcis.vMin = 0.2;
cfg2.rcis.vMax = 7.8;
cfg2.rcis.relativeBraking = 0.8;

% Scalar input search. The grid avoids an Optimization Toolbox dependency.
cfg2.filter.uGrid = linspace( ...
    cfg1.input.umin, cfg1.input.umax, 1401);
cfg2.filter.feasibilityTolerance = 1e-10;

% This performance controller does not enforce coupled safety by itself.
cfg2.nominal.desiredSpeed = 4.6;
cfg2.nominal.kSpeed = 0.65;
cfg2.nominal.kError = 0.15;

cfg2.initial.error = [0.10; 0.05; 0.00; -0.05; -0.10];
cfg2.initial.velocity = [4.50; 4.45; 4.40; 4.35; 4.30];

cfg2.disturbance.amplitude = 0.08;
cfg2.disturbance.frequency = 0.50;
cfg2.disturbance.phase = 0.70 * (0:cfg1.N-1).';

cfg2.validation.tolerance = 1e-8;
cfg2.resultsDir = fullfile(projectRoot, 'results_stage2');
end
