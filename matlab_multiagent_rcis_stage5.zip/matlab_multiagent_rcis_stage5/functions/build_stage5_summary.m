function summary = build_stage5_summary(results, initialCells, cfg1)
%BUILD_STAGE5_SUMMARY Per-agent continuous-domain certificate metrics.

agent = (1:cfg1.N).';
initialIntersectingCells = repmat( ...
    initialCells.intersectingCellCount, cfg1.N, 1);
certifiedLeaves = zeros(cfg1.N, 1);
unresolvedLeaves = zeros(cfg1.N, 1);
evaluatedCells = zeros(cfg1.N, 1);
maximumDepth = zeros(cfg1.N, 1);
worstCertifiedMargin = zeros(cfg1.N, 1);
completeCertificate = false(cfg1.N, 1);
policyLambda = zeros(cfg1.N, 1);

for i = 1:cfg1.N
    certifiedLeaves(i) = results{i}.certifiedLeafCount;
    unresolvedLeaves(i) = results{i}.unresolvedLeafCount;
    evaluatedCells(i) = results{i}.evaluatedCellCount;
    maximumDepth(i) = results{i}.maximumDepthUsed;
    worstCertifiedMargin(i) = results{i}.worstCertifiedMargin;
    completeCertificate(i) = results{i}.completeCertificate;
    policyLambda(i) = results{i}.policy.lambda;
end

summary = table(agent, initialIntersectingCells, ...
    certifiedLeaves, unresolvedLeaves, evaluatedCells, ...
    maximumDepth, worstCertifiedMargin, policyLambda, ...
    completeCertificate);
end
