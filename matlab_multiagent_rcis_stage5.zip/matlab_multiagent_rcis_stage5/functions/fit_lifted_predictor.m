function model = fit_lifted_predictor(data)
%FIT_LIFTED_PREDICTOR Minimum-norm data predictor in lifted coordinates.

Phi = lifted_features(data.qMeasured);
singularValues = svd(Phi);
rankTolerance = max(size(Phi)) * eps(max(singularValues));
numericalRank = sum(singularValues > rankTolerance);

if numericalRank < size(Phi, 1)
    error('The lifted local data matrix does not have full row rank.');
end

gram = Phi * Phi.';
G = Phi.' / gram;
rightInverseError = norm(Phi * G - eye(size(Phi, 1)), 'fro');

model.G = G;
model.M = data.X1 * G;
model.Phi = Phi;
model.X1 = data.X1;
model.singularValues = singularValues;
model.sigmaMin = singularValues(end);
model.conditionNumber = singularValues(1) / singularValues(end);
model.numericalRank = numericalRank;
model.rightInverseError = rightInverseError;

assert(rightInverseError <= 1e-8, ...
    'The lifted minimum-norm matrix is not a numerical right inverse.');
end
