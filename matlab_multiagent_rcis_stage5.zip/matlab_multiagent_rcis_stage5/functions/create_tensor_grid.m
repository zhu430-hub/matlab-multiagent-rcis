function qGrid = create_tensor_grid(lowerBound, upperBound, pointsPerDimension)
%CREATE_TENSOR_GRID Create a full tensor calibration grid.

dimension = numel(lowerBound);
axesCell = cell(dimension, 1);
gridCell = cell(dimension, 1);

for j = 1:dimension
    axesCell{j} = linspace( ...
        lowerBound(j), upperBound(j), pointsPerDimension);
end

[gridCell{:}] = ndgrid(axesCell{:});

gridCount = numel(gridCell{1});
qGrid = zeros(dimension, gridCount);
for j = 1:dimension
    qGrid(j, :) = reshape(gridCell{j}, 1, []);
end
end
