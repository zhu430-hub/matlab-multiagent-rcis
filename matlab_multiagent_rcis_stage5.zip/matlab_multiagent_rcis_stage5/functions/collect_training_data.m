function data = collect_training_data(cfg, agentIndex)
%COLLECT_TRAINING_DATA Collect noisy one-step data for one agent.

qTrue = sample_uniform_box( ...
    cfg.range.lower, cfg.range.upper, cfg.data.nTrain);
xNextTrue = vehicle_step_true(qTrue, cfg, agentIndex);
[qMeasured, xNextMeasured, noise] = add_measurement_noise( ...
    qTrue, xNextTrue, cfg);

data.U0 = qMeasured(1, :);
data.X0 = qMeasured(2:3, :);
data.Z0 = qMeasured(4:5, :);
data.X1 = xNextMeasured;
data.W = [data.U0; data.X0; data.Z0; ones(1, cfg.data.nTrain)];

data.qTrue = qTrue;
data.qMeasured = qMeasured;
data.xNextTrue = xNextTrue;
data.noise = noise;
end
