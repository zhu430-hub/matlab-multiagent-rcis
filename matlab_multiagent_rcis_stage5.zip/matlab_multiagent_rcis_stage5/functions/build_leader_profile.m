function leader = build_leader_profile(cfg1, cfg2)
%BUILD_LEADER_PROFILE Virtual leader with braking and recovery manoeuvres.

t = cfg2.time;
leader.velocity = zeros(size(t));
leader.acceleration = zeros(1, cfg2.nSteps);
leader.velocity(1) = 4.5;

for k = 1:cfg2.nSteps
    if t(k) < 2.0
        acceleration = 0.0;
    elseif t(k) < 4.0
        acceleration = -0.5;
    elseif t(k) < 7.0
        acceleration = 0.25;
    else
        acceleration = 0.0;
    end

    leader.acceleration(k) = acceleration;
    leader.velocity(k + 1) = min(max( ...
        leader.velocity(k) + cfg1.Ts * acceleration, ...
        cfg1.range.lower(4)), cfg1.range.upper(4));
end
end
