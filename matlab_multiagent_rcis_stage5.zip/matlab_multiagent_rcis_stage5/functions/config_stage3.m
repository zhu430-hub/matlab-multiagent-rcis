function cfg3 = config_stage3(cfg1, projectRoot)
%CONFIG_STAGE3 Offline grid certificate for a coupled robust ellipsoidal set.

cfg3.operating.eCenter = -0.75;
cfg3.operating.vMin = 2.80;
cfg3.operating.vMax = 6.20;
cfg3.operating.vRefMin = 3.50;
cfg3.operating.vRefMax = 5.50;
cfg3.operating.aRefMin = -0.50;
cfg3.operating.aRefMax = 0.20;

% Offline shape search penalizes relative velocity strongly and uses a
% positive cross term to enforce inward motion near spacing boundaries.
cfg3.ellipsoid.relativeWeight = 128.0;
cfg3.ellipsoid.correlation = 0.10;
crossTerm = cfg3.ellipsoid.correlation * ...
    sqrt(cfg3.ellipsoid.relativeWeight);
rawP = [1, crossTerm; crossTerm, cfg3.ellipsoid.relativeWeight];
cfg3.ellipsoid.P = rawP / sqrt(det(rawP));

inverseP = inv(cfg3.ellipsoid.P);
cfg3.grid.errorRadius = 2.70;
cfg3.ellipsoid.rho = cfg3.grid.errorRadius^2 / inverseP(1, 1);
cfg3.grid.relativeVelocityRadius = sqrt( ...
    cfg3.ellipsoid.rho * inverseP(2, 2));
cfg3.grid.nError = 31;
cfg3.grid.nRelativeVelocity = 31;
cfg3.grid.nReferenceVelocity = 13;
cfg3.grid.disturbance = [-0.15, 0, 0.15];

cfg3.input.uGrid = linspace( ...
    cfg1.input.umin, cfg1.input.umax, 351);
cfg3.computation.stateChunk = 256;
cfg3.envelope.nGridPerDimension = 7;
cfg3.validation.tolerance = 1e-9;
cfg3.resultsDir = fullfile(projectRoot, 'results_stage3');
end
