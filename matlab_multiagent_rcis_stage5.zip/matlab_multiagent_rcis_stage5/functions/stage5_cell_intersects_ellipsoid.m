function intersects = stage5_cell_intersects_ellipsoid( ...
    lower, upper, cfg3)
%STAGE5_CELL_INTERSECTS_ELLIPSOID Exact 2-D box/ellipsoid intersection.

xLower = lower(1, :) - cfg3.operating.eCenter;
xUpper = upper(1, :) - cfg3.operating.eCenter;
yLower = lower(2, :);
yUpper = upper(2, :);
P = cfg3.ellipsoid.P;

minimumValue = inf(1, size(lower, 2));
containsOrigin = xLower <= 0 & xUpper >= 0 ...
    & yLower <= 0 & yUpper >= 0;
minimumValue(containsOrigin) = 0;

xBounds = [xLower; xUpper];
for boundary = 1:2
    x = xBounds(boundary, :);
    yStationary = -(P(1, 2) / P(2, 2)) .* x;
    y = min(max(yStationary, yLower), yUpper);
    minimumValue = min(minimumValue, ...
        quadratic_value(x, y, P));
end

yBounds = [yLower; yUpper];
for boundary = 1:2
    y = yBounds(boundary, :);
    xStationary = -(P(1, 2) / P(1, 1)) .* y;
    x = min(max(xStationary, xLower), xUpper);
    minimumValue = min(minimumValue, ...
        quadratic_value(x, y, P));
end

intersects = minimumValue <= ...
    cfg3.ellipsoid.rho + cfg3.validation.tolerance;
end

function value = quadratic_value(x, y, P)
value = P(1, 1) * x.^2 ...
    + 2 * P(1, 2) * x .* y ...
    + P(2, 2) * y.^2;
end
