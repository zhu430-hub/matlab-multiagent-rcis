function children = split_stage5_cells(cells, cfg3, cfg5)
%SPLIT_STAGE5_CELLS Bisect each unresolved box in its dominant dimension.

n = size(cells.lower, 2);
width = cells.upper - cells.lower;
scaledWidth = width ./ cfg5.refinement.targetWidth;
[~, splitDimension] = max(scaledWidth, [], 1);

children.lower = zeros(4, 2 * n);
children.upper = zeros(4, 2 * n);
children.depth = zeros(1, 2 * n);
for i = 1:n
    midpoint = 0.5 * (cells.lower(splitDimension(i), i) ...
        + cells.upper(splitDimension(i), i));
    firstChild = 2 * i - 1;
    secondChild = 2 * i;
    children.lower(:, firstChild) = cells.lower(:, i);
    children.upper(:, firstChild) = cells.upper(:, i);
    children.upper(splitDimension(i), firstChild) = midpoint;
    children.lower(:, secondChild) = cells.lower(:, i);
    children.upper(:, secondChild) = cells.upper(:, i);
    children.lower(splitDimension(i), secondChild) = midpoint;
    children.depth([firstChild, secondChild]) = ...
        cells.depth(i) + 1;
end

intersects = stage5_cell_intersects_ellipsoid( ...
    children.lower, children.upper, cfg3);
children.lower = children.lower(:, intersects);
children.upper = children.upper(:, intersects);
children.depth = children.depth(intersects);
end
