function plot_stage2_results(nominal, safe, leader, cfg1, cfg2)
%PLOT_STAGE2_RESULTS Publication-oriented Stage 2 figures.

t = cfg2.time;
tControl = t(1:end-1);
colors = lines(cfg1.N);

figure('Color', 'w', 'Position', [80, 80, 1300, 800]);
tiledlayout(2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

nexttile;
hold on;
for i = 1:cfg1.N
    plot(t, squeeze(safe.x(1, i, :)), ...
        'LineWidth', 1.6, 'Color', colors(i, :));
end
yline(cfg2.rcis.eMax, 'r--', ...
    'Upper RCIS boundary', 'LineWidth', 1.4);
yline(cfg2.rcis.eMin, 'r--', ...
    'Lower RCIS boundary', 'LineWidth', 1.4);
grid on;
xlabel('Time (s)');
ylabel('Relative error e_i');
title('Distributed DD-RCIS: coupled errors');

nexttile;
hold on;
plot(t, leader.velocity, 'k--', 'LineWidth', 2.0);
for i = 1:cfg1.N
    plot(t, squeeze(safe.x(2, i, :)), ...
        'LineWidth', 1.5, 'Color', colors(i, :));
end
yline(cfg2.rcis.vMin, 'r--', 'LineWidth', 1.2);
yline(cfg2.rcis.vMax, 'r--', 'LineWidth', 1.2);
grid on;
xlabel('Time (s)');
ylabel('Velocity');
title('One-hop velocity coupling');

nexttile;
hold on;
for i = 1:cfg1.N
    stairs(tControl, safe.u(i, :), ...
        'LineWidth', 1.4, 'Color', colors(i, :));
end
yline(cfg1.input.umin, 'r--', ...
    'Input limits', 'LineWidth', 1.2);
yline(cfg1.input.umax, 'r--', 'LineWidth', 1.2);
grid on;
xlabel('Time (s)');
ylabel('u_i');
title('Hard-constrained distributed inputs');

nexttile;
hold on;
plot(tControl, min(safe.certificateMargin, [], 1), ...
    'b-', 'LineWidth', 1.7);
yline(0, 'r--', ...
    'Feasibility boundary', 'LineWidth', 1.3);
grid on;
xlabel('Time (s)');
ylabel('Minimum certified margin');
title('Recursive-feasibility certificate');

exportgraphics(gcf, fullfile(cfg2.resultsDir, ...
    'fig_stage2_distributed_closed_loop.png'), 'Resolution', 220);

figure('Color', 'w', 'Position', [100, 100, 1300, 760]);
tiledlayout(2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

nexttile;
hold on;
plot(t, squeeze(max(nominal.x(1, :, :), [], 2)), ...
    'Color', [0.85, 0.33, 0.10], 'LineWidth', 1.8);
plot(t, squeeze(max(safe.x(1, :, :), [], 2)), ...
    'Color', [0.00, 0.45, 0.74], 'LineWidth', 1.8);
yline(cfg2.rcis.eMax, 'r--', ...
    'Upper RCIS boundary', 'LineWidth', 1.3);
grid on;
xlabel('Time (s)');
ylabel('max_i e_i');
title('Worst coupled spacing error');
legend('Nominal', 'Distributed DD-RCIS', 'Location', 'best');

nexttile;
hold on;
plot(t, min(nominal.actualBarrier, [], 1), ...
    'Color', [0.85, 0.33, 0.10], 'LineWidth', 1.8);
plot(t, min(safe.actualBarrier, [], 1), ...
    'Color', [0.00, 0.45, 0.74], 'LineWidth', 1.8);
yline(0, 'r--', 'Safety boundary', 'LineWidth', 1.3);
grid on;
xlabel('Time (s)');
ylabel('min_i h_i');
title('Braking-distance barrier');
legend('Nominal', 'Distributed DD-RCIS', 'Location', 'best');

nexttile;
stairs(tControl, min(safe.feasibleCount, [], 1), ...
    'k-', 'LineWidth', 1.6);
grid on;
xlabel('Time (s)');
ylabel('Minimum feasible input count');
title('Available safe inputs at every step');

nexttile;
imagesc(tControl, 1:cfg1.N, safe.filterActive);
axis xy;
colormap(gca, [1, 1, 1; 0.00, 0.45, 0.74]);
caxis([0, 1]);
colorbar('Ticks', [0, 1], ...
    'TickLabels', {'inactive', 'active'});
xlabel('Time (s)');
ylabel('Agent');
title('Distributed filter activation');

exportgraphics(gcf, fullfile(cfg2.resultsDir, ...
    'fig_stage2_method_comparison.png'), 'Resolution', 220);
end
