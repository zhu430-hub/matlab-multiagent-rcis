function envelope = build_calibration_envelope(model, cfg, agentIndex)
%BUILD_CALIBRATION_ENVELOPE Construct the deterministic residual envelope.

qGrid = create_tensor_grid( ...
    cfg.range.lower, cfg.range.upper, cfg.data.nGridPerDimension);
xNextTrue = vehicle_step_true(qGrid, cfg, agentIndex);
[qMeasured, xNextMeasured] = add_measurement_noise( ...
    qGrid, xNextTrue, cfg);

wMeasured = [qMeasured; ones(1, size(qMeasured, 2))];
observedResidual = xNextMeasured - model.M * wMeasured;

xiGrid = normalize_operating_point(qGrid, cfg);
augmentedNorm = sqrt(sum(xiGrid.^2, 1) + 1);

etaNoise = measurement_noise_support(model, cfg);
sampleUpperBound = abs(observedResidual) + etaNoise;

kappa = max(sampleUpperBound ./ augmentedNorm, [], 2);

dimension = cfg.dim.q;
gridSpacing = 2 / (cfg.data.nGridPerDimension - 1);
epsilonCover = 0.5 * sqrt(dimension) * gridSpacing;

noiseQ = [0; cfg.noise.x; cfg.noise.z];
normalizedNoiseRadius = 2 .* noiseQ ./ ...
    (cfg.range.upper - cfg.range.lower);
deltaXi = norm(normalizedNoiseRadius, 2);

lipschitz = residual_lipschitz_bound(model, cfg, agentIndex);

envelope.kappa = kappa;
envelope.lipschitz = lipschitz;
envelope.epsilonCover = epsilonCover;
envelope.deltaXi = deltaXi;
envelope.etaNoise = etaNoise;
envelope.qGrid = qGrid;
envelope.observedResidual = observedResidual;
envelope.sampleUpperBound = sampleUpperBound;
envelope.nCalibration = size(qGrid, 2);
end
