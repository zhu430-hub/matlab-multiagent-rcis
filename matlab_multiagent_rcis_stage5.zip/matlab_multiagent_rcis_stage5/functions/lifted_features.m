function phi = lifted_features(q)
%LIFTED_FEATURES Data-driven feature library for the local predictor.
%
% q is ordered as [u; e; v; v_ref; d].  The additional v*abs(v)
% coordinate represents the dominant nonlinear drag without identifying
% the drag coefficient explicitly.

phi = [q; q(3, :) .* abs(q(3, :)); ones(1, size(q, 2))];
end
