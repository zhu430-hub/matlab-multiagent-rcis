function validation = validate_error_envelope( ...
    model, envelope, cfg, agentIndex)
%VALIDATE_ERROR_ENVELOPE Validate on independent random operating points.

qTrue = sample_uniform_box( ...
    cfg.range.lower, cfg.range.upper, cfg.data.nTest);
xNextTrue = vehicle_step_true(qTrue, cfg, agentIndex);
[qMeasured, xNextMeasured] = add_measurement_noise( ...
    qTrue, xNextTrue, cfg);

wMeasured = [qMeasured; ones(1, cfg.data.nTest)];
xNextPredicted = model.M * wMeasured;
residual = xNextMeasured - xNextPredicted;
beta = evaluate_error_bound(qMeasured, envelope, cfg);

ratio = abs(residual) ./ beta;

validation.qTrue = qTrue;
validation.qMeasured = qMeasured;
validation.xNextMeasured = xNextMeasured;
validation.xNextPredicted = xNextPredicted;
validation.residual = residual;
validation.beta = beta;
validation.ratio = ratio;
validation.maxRatioByState = max(ratio, [], 2);
validation.maxRatio = max(ratio(:));
validation.meanRatio = mean(ratio(:));
validation.coverageRate = mean( ...
    ratio(:) <= 1 + cfg.validation.tolerance);
validation.meanBetaByState = mean(beta, 2);
validation.maxResidualByState = max(abs(residual), [], 2);
end
