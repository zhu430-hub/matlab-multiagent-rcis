function result = validate_lifted_envelope( ...
    model, envelope, cfg, agentIndex)
%VALIDATE_LIFTED_ENVELOPE Independent measured held-out validation.

qTrue = sample_uniform_box( ...
    cfg.range.lower, cfg.range.upper, cfg.data.nTest);
xNextTrue = vehicle_step_true(qTrue, cfg, agentIndex);
[qMeasured, xNextMeasured] = add_measurement_noise( ...
    qTrue, xNextTrue, cfg);

prediction = model.M * lifted_features(qMeasured);
beta = evaluate_lifted_error_bound(qMeasured, envelope);
ratio = abs(xNextMeasured - prediction) ./ beta;

result.maximumRatioByState = max(ratio, [], 2);
result.maximumRatio = max(ratio(:));
result.coverage = mean(ratio(:) <= 1 + cfg.validation.tolerance);
result.nTest = size(qTrue, 2);
end
