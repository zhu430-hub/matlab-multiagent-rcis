function beta = evaluate_lifted_error_bound(q, envelope)
%EVALUATE_LIFTED_ERROR_BOUND Repeat the certified uniform row-wise bound.

beta = repmat(envelope.beta, 1, size(q, 2));
end
