function eta = measurement_noise_support(model, cfg)
%MEASUREMENT_NOISE_SUPPORT Row-wise support of bounded measurement noise.
%
% The online residual is
%   r_m = r_0 + v_x^+ - M_x v_x - M_z v_z.

M = model.M;
eta = cfg.noise.x ...
    + abs(M(:, 2:3)) * cfg.noise.x ...
    + abs(M(:, 4:5)) * cfg.noise.z;
end
