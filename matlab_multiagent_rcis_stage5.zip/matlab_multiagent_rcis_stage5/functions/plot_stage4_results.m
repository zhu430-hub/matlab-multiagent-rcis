function plot_stage4_results(scenarioTable, cfg4)
%PLOT_STAGE4_RESULTS Scenario-wise success and violation comparison.

scenarioNames = string({cfg4.scenario.name}).';
nScenarios = numel(scenarioNames);
nominalSuccess = nan(nScenarios, 1);
safeSuccess = nan(nScenarios, 1);
nominalViolations = nan(nScenarios, 1);
safeViolations = nan(nScenarios, 1);
for i = 1:nScenarios
    nominalRow = scenarioTable.scenarioName == scenarioNames(i) ...
        & scenarioTable.methodName == "Nominal";
    safeRow = scenarioTable.scenarioName == scenarioNames(i) ...
        & scenarioTable.methodName == "Distributed DD-RCIS";
    assert(sum(nominalRow) == 1 && sum(safeRow) == 1, ...
        'A Stage 4 scenario/method summary row is missing.');
    nominalSuccess(i) = scenarioTable.successRate(nominalRow);
    safeSuccess(i) = scenarioTable.successRate(safeRow);
    nominalViolations(i) = ...
        scenarioTable.totalEllipsoidViolations(nominalRow);
    safeViolations(i) = ...
        scenarioTable.totalEllipsoidViolations(safeRow);
end
names = categorical(scenarioNames, scenarioNames, 'Ordinal', true);

figure('Color', 'w', 'Position', [100, 100, 1050, 420]);
tiledlayout(1, 2, 'Padding', 'compact', 'TileSpacing', 'compact');

nexttile;
bar(names, [nominalSuccess, safeSuccess]);
ylim([0, 1.05]);
ylabel('Successful trial fraction');
legend({'Nominal', 'Distributed DD-RCIS'}, 'Location', 'southwest');
set(gca, 'XGrid', 'on', 'YGrid', 'on');

nexttile;
bar(names, [nominalViolations, safeViolations]);
ylabel('Total ellipsoid violations');
legend({'Nominal', 'Distributed DD-RCIS'}, 'Location', 'northwest');
set(gca, 'XGrid', 'on', 'YGrid', 'on');

exportgraphics(gcf, fullfile(cfg4.resultsDir, ...
    'fig_stage4_monte_carlo.png'), 'Resolution', 180);
close(gcf);
end
