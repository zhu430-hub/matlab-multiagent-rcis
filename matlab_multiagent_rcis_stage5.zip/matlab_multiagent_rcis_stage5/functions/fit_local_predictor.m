function model = fit_local_predictor(data, cfg)
%FIT_LOCAL_PREDICTOR Fit X1*G using the fixed minimum-norm right inverse.

W = data.W;
singularValues = svd(W);
rankTolerance = max(size(W)) * eps(max(singularValues));
numericalRank = sum(singularValues > rankTolerance);

if numericalRank < cfg.dim.w
    error('The local data matrix W does not have full row rank.');
end

gram = W * W.';
G = W.' / gram;
rightInverseError = norm(W * G - eye(cfg.dim.w), 'fro');

model.G = G;
model.M = data.X1 * G;
model.W = W;
model.X1 = data.X1;
model.singularValues = singularValues;
model.sigmaMin = singularValues(end);
model.conditionNumber = singularValues(1) / singularValues(end);
model.numericalRank = numericalRank;
model.rightInverseError = rightInverseError;

assert(rightInverseError <= 1e-9, ...
    'The computed minimum-norm matrix is not a numerical right inverse.');
end
