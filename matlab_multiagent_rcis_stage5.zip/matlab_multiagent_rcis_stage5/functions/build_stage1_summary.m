function summary = build_stage1_summary( ...
    models, calibration, validation, cfg)
%BUILD_STAGE1_SUMMARY Create a compact per-agent result table.

agent = (1:cfg.N).';
dragCoefficient = cfg.plant.drag(:);
sigmaMin = zeros(cfg.N, 1);
conditionNumber = zeros(cfg.N, 1);
rightInverseError = zeros(cfg.N, 1);
calibrationPoints = zeros(cfg.N, 1);
epsilonCover = zeros(cfg.N, 1);
maxResidualRatio = zeros(cfg.N, 1);
meanResidualRatio = zeros(cfg.N, 1);
coverageRate = zeros(cfg.N, 1);

for i = 1:cfg.N
    sigmaMin(i) = models{i}.sigmaMin;
    conditionNumber(i) = models{i}.conditionNumber;
    rightInverseError(i) = models{i}.rightInverseError;
    calibrationPoints(i) = calibration{i}.nCalibration;
    epsilonCover(i) = calibration{i}.epsilonCover;
    maxResidualRatio(i) = validation{i}.maxRatio;
    meanResidualRatio(i) = validation{i}.meanRatio;
    coverageRate(i) = validation{i}.coverageRate;
end

summary = table( ...
    agent, dragCoefficient, sigmaMin, conditionNumber, ...
    rightInverseError, calibrationPoints, epsilonCover, ...
    maxResidualRatio, meanResidualRatio, coverageRate, ...
    'VariableNames', { ...
    'Agent', 'DragCoefficient', 'SigmaMinW', 'ConditionNumberW', ...
    'RightInverseError', 'CalibrationPoints', 'EpsilonCover', ...
    'MaxResidualRatio', 'MeanResidualRatio', 'CoverageRate'});
end
