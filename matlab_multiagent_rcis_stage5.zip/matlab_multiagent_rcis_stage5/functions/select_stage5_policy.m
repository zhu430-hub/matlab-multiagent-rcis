function policy = select_stage5_policy( ...
    cells, model, envelope, cfg1, cfg3, cfg5)
%SELECT_STAGE5_POLICY Pick the best inward slope on the initial cover.

lambdaGrid = 0:0.10:1.50;
accelerationGrid = [cfg3.operating.aRefMin, -0.30, ...
    -0.15, 0, cfg3.operating.aRefMax];
[lambdaCandidate, accelerationCandidate] = ndgrid( ...
    lambdaGrid, accelerationGrid);
lambdaCandidate = lambdaCandidate(:);
accelerationCandidate = accelerationCandidate(:);
certifiedCount = zeros(size(lambdaCandidate));
meanClippedMargin = zeros(size(lambdaCandidate));
for i = 1:numel(lambdaCandidate)
    candidate = stage5_policy_coefficients( ...
        model, lambdaCandidate(i), accelerationCandidate(i), ...
        cfg3, cfg1.Ts);
    margin = evaluate_stage5_policy_cells( ...
        cells, model, envelope, candidate, ...
        cfg1, cfg3, cfg5);
    certifiedCount(i) = sum(margin >= ...
        -cfg5.refinement.feasibilityTolerance);
    meanClippedMargin(i) = mean(max(margin, -1));
end

bestCount = max(certifiedCount);
eligible = find(certifiedCount == bestCount);
[~, localBest] = max(meanClippedMargin(eligible));
bestIndex = eligible(localBest);
policy = stage5_policy_coefficients( ...
    model, lambdaCandidate(bestIndex), ...
    accelerationCandidate(bestIndex), cfg3, cfg1.Ts);
policy.initialCertifiedCount = certifiedCount(bestIndex);
end
