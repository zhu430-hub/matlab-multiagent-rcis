function policy = select_stage5_policy( ...
    cells, model, envelope, cfg1, cfg3, cfg5)
%SELECT_STAGE5_POLICY Pick the best inward slope on the initial cover.

lambdaGrid = 0:0.01:0.15;
certifiedCount = zeros(size(lambdaGrid));
meanClippedMargin = zeros(size(lambdaGrid));
for i = 1:numel(lambdaGrid)
    candidate = stage5_policy_coefficients( ...
        model, lambdaGrid(i), cfg3, cfg1.Ts);
    margin = evaluate_stage5_policy_cells( ...
        cells, model, envelope, candidate, ...
        cfg1, cfg3, cfg5);
    certifiedCount(i) = sum(margin >= ...
        -cfg5.refinement.feasibilityTolerance);
    meanClippedMargin(i) = mean(max(margin, -1));
end

bestCount = max(certifiedCount);
eligible = find(certifiedCount == bestCount);
[~, localBest] = max(meanClippedMargin(eligible));
bestIndex = eligible(localBest);
policy = stage5_policy_coefficients( ...
    model, lambdaGrid(bestIndex), cfg3, cfg1.Ts);
policy.initialCertifiedCount = certifiedCount(bestIndex);
end
