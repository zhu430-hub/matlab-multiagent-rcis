function lipschitz = residual_lipschitz_bound(model, cfg, agentIndex)
%RESIDUAL_LIPSCHITZ_BOUND Simulation-known Lipschitz bound.
%
% This routine uses the true plant derivative only to supply the assumed
% residual Lipschitz constant in the numerical experiment. It is not used
% by the data-driven predictor.

Ts = cfg.Ts;
c = cfg.plant.drag(agentIndex);
scale = 0.5 * (cfg.range.upper - cfg.range.lower);
scaleMatrix = diag(scale);
Mq = model.M(:, 1:cfg.dim.q);

velocityEndpoints = [cfg.range.lower(3), cfg.range.upper(3)];
gradientNorms = zeros(cfg.dim.x, numel(velocityEndpoints));

for k = 1:numel(velocityEndpoints)
    v = velocityEndpoints(k);

    % Jacobian of f(q) with q = [u; e; v; v_ref; d].
    Jf = [ ...
        0.5 * Ts^2, 1, Ts - Ts^2 * c * v, -Ts, 0.5 * Ts^2; ...
        Ts,          0, 1 - 2 * Ts * c * v, 0, Ts];

    normalizedResidualJacobian = (Jf - Mq) * scaleMatrix;
    gradientNorms(:, k) = sqrt(sum(normalizedResidualJacobian.^2, 2));
end

% The gradient norm is a convex function of v on the interval, so its
% maximum occurs at an endpoint.
lipschitz = max(gradientNorms, [], 2);
end
