function result = certify_stage5_agent( ...
    initialCells, model, envelope, cfg1, cfg3, cfg5)
%CERTIFY_STAGE5_AGENT Adaptively certify every intersecting state box.

pending.lower = initialCells.lower;
pending.upper = initialCells.upper;
pending.depth = initialCells.depth;

certifiedLeafCount = 0;
evaluatedCellCount = 0;
worstCertifiedMargin = inf;
maximumDepthUsed = 0;
certificate.lower = zeros(4, 0);
certificate.upper = zeros(4, 0);
certificate.depth = zeros(1, 0);
certificate.input = zeros(1, 0);
certificate.margin = zeros(1, 0);
unresolved.lower = zeros(4, 0);
unresolved.upper = zeros(4, 0);
unresolved.depth = zeros(1, 0);

while ~isempty(pending.depth)
    if numel(pending.depth) > cfg5.refinement.maxPendingCells
        error('Stage 5 exceeded the configured pending-cell limit.');
    end

    [margin, input] = evaluate_stage5_cells( ...
        pending, model, envelope, cfg1, cfg3, cfg5);
    evaluatedCellCount = evaluatedCellCount + numel(margin);
    certified = margin >= ...
        -cfg5.refinement.feasibilityTolerance;

    if any(certified)
        certifiedLeafCount = certifiedLeafCount + sum(certified);
        worstCertifiedMargin = min( ...
            worstCertifiedMargin, min(margin(certified)));
        maximumDepthUsed = max(maximumDepthUsed, ...
            max(pending.depth(certified)));
        certificate.lower = [certificate.lower, ...
            pending.lower(:, certified)];
        certificate.upper = [certificate.upper, ...
            pending.upper(:, certified)];
        certificate.depth = [certificate.depth, ...
            pending.depth(certified)];
        certificate.input = [certificate.input, ...
            input(certified)];
        certificate.margin = [certificate.margin, ...
            margin(certified)];
    end

    failed = ~certified;
    if ~any(failed)
        pending.depth = zeros(1, 0);
        break;
    end

    canRefine = failed & ...
        pending.depth < cfg5.refinement.maxDepth;
    cannotRefine = failed & ~canRefine;
    if any(cannotRefine)
        unresolved.lower = [unresolved.lower, ...
            pending.lower(:, cannotRefine)];
        unresolved.upper = [unresolved.upper, ...
            pending.upper(:, cannotRefine)];
        unresolved.depth = [unresolved.depth, ...
            pending.depth(cannotRefine)];
    end

    if any(canRefine)
        toSplit.lower = pending.lower(:, canRefine);
        toSplit.upper = pending.upper(:, canRefine);
        toSplit.depth = pending.depth(canRefine);
        pending = split_stage5_cells(toSplit, cfg3, cfg5);
    else
        pending.lower = zeros(4, 0);
        pending.upper = zeros(4, 0);
        pending.depth = zeros(1, 0);
    end

    maximumDepthUsed = max(maximumDepthUsed, ...
        max([0, pending.depth]));
end

result.certifiedLeafCount = certifiedLeafCount;
result.unresolvedLeafCount = numel(unresolved.depth);
result.evaluatedCellCount = evaluatedCellCount;
result.maximumDepthUsed = maximumDepthUsed;
result.worstCertifiedMargin = worstCertifiedMargin;
result.certificate = certificate;
result.unresolved = unresolved;
result.completeCertificate = isempty(unresolved.depth);
end
