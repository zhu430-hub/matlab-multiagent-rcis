function result = certify_stage5_agent( ...
    initialCells, model, envelope, cfg1, cfg3, cfg5)
%CERTIFY_STAGE5_AGENT Adaptively certify every intersecting state box.

pending.lower = initialCells.lower;
pending.upper = initialCells.upper;
pending.depth = initialCells.depth;
policy = select_stage5_policy( ...
    pending, model, envelope, cfg1, cfg3, cfg5);
fprintf('    selected policy lambda: %.4f\n', policy.lambda);
[initialMargin, ~, ~, initialDiagnostics] = ...
    evaluate_stage5_policy_cells( ...
    pending, model, envelope, policy, cfg1, cfg3, cfg5);
fprintf('    selected acceleration center: %.4f\n', ...
    policy.accelerationCenter);
failedInitial = initialMargin < ...
    -cfg5.refinement.feasibilityTolerance;
for k = 1:numel(initialDiagnostics.constraintNames)
    fprintf('    initial failures limited by %s: %d\n', ...
        initialDiagnostics.constraintNames(k), ...
        sum(failedInitial & ...
        initialDiagnostics.limitingConstraint == k));
end
for k = 1:numel(initialDiagnostics.regimeNames)
    fprintf('    initial cells in %s regime: %d\n', ...
        initialDiagnostics.regimeNames(k), ...
        sum(initialDiagnostics.regime == k));
end

certifiedLeafCount = 0;
evaluatedCellCount = 0;
worstCertifiedMargin = inf;
maximumDepthUsed = 0;
worstCertificate.lower = nan(4, 1);
worstCertificate.upper = nan(4, 1);
worstCertificate.depth = nan;
worstCertificate.input = nan;
worstCertificate.margin = nan;
unresolved.lower = zeros(4, 0);
unresolved.upper = zeros(4, 0);
unresolved.depth = zeros(1, 0);

while ~isempty(pending.depth)
    if numel(pending.depth) > cfg5.refinement.maxPendingCells
        error('Stage 5 exceeded the configured pending-cell limit.');
    end

    [margin, inputLower, inputUpper] = ...
        evaluate_stage5_policy_cells( ...
        pending, model, envelope, policy, ...
        cfg1, cfg3, cfg5);
    evaluatedCellCount = evaluatedCellCount + numel(margin);
    certified = margin >= ...
        -cfg5.refinement.feasibilityTolerance;
    fprintf(['    depth %d: pending %d, certified %d, ' ...
        'refine %d\n'], min(pending.depth), numel(margin), ...
        sum(certified), sum(~certified));

    if any(certified)
        certifiedLeafCount = certifiedLeafCount + sum(certified);
        certifiedIndices = find(certified);
        [iterationWorstMargin, localWorstIndex] = ...
            min(margin(certified));
        if iterationWorstMargin < worstCertifiedMargin
            worstCertifiedMargin = iterationWorstMargin;
            worstIndex = certifiedIndices(localWorstIndex);
            worstCertificate.lower = pending.lower(:, worstIndex);
            worstCertificate.upper = pending.upper(:, worstIndex);
            worstCertificate.depth = pending.depth(worstIndex);
            worstCertificate.input = [ ...
                inputLower(worstIndex), inputUpper(worstIndex)];
            worstCertificate.margin = margin(worstIndex);
        end
        maximumDepthUsed = max(maximumDepthUsed, ...
            max(pending.depth(certified)));
    end

    failed = ~certified;
    if ~any(failed)
        pending.depth = zeros(1, 0);
        break;
    end

    canRefine = failed & ...
        pending.depth < cfg5.refinement.maxDepth;
    cannotRefine = failed & ~canRefine;
    if any(cannotRefine)
        unresolved.lower = [unresolved.lower, ...
            pending.lower(:, cannotRefine)];
        unresolved.upper = [unresolved.upper, ...
            pending.upper(:, cannotRefine)];
        unresolved.depth = [unresolved.depth, ...
            pending.depth(cannotRefine)];
    end

    if any(canRefine)
        toSplit.lower = pending.lower(:, canRefine);
        toSplit.upper = pending.upper(:, canRefine);
        toSplit.depth = pending.depth(canRefine);
        pending = split_stage5_cells(toSplit, cfg3, cfg5);
    else
        pending.lower = zeros(4, 0);
        pending.upper = zeros(4, 0);
        pending.depth = zeros(1, 0);
    end

    maximumDepthUsed = max(maximumDepthUsed, ...
        max([0, pending.depth]));
end

result.certifiedLeafCount = certifiedLeafCount;
result.unresolvedLeafCount = numel(unresolved.depth);
result.evaluatedCellCount = evaluatedCellCount;
result.maximumDepthUsed = maximumDepthUsed;
result.worstCertifiedMargin = worstCertifiedMargin;
result.worstCertificate = worstCertificate;
result.policy = policy;
result.unresolved = unresolved;
result.completeCertificate = isempty(unresolved.depth);
end
