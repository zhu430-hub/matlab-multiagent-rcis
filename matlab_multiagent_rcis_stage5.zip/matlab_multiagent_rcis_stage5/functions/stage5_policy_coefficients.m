function policy = stage5_policy_coefficients(model, lambda, cfg3, Ts)
%STAGE5_POLICY_COEFFICIENTS Data-driven inward-pointing feedback law.

velocityRow = model.M(2, :);
errorRow = model.M(1, :);
if abs(velocityRow(1)) <= 1e-8
    error('The learned velocity input gain is numerically singular.');
end

accelerationCenter = 0.5 * ( ...
    cfg3.operating.aRefMin + cfg3.operating.aRefMax);

% u = c*[e,r,v_ref,d,(r+v_ref)^2,1], selected so that the
% predicted next velocity is
% v_ref + Ts*a_center - lambda*(e-e_center).
c = zeros(1, 6);
c(1) = (-lambda - velocityRow(2)) / velocityRow(1);
c(2) = -velocityRow(3) / velocityRow(1);
c(3) = (1 - velocityRow(3) - velocityRow(4)) ...
    / velocityRow(1);
c(4) = -velocityRow(5) / velocityRow(1);
c(5) = -velocityRow(6) / velocityRow(1);
c(6) = (Ts * accelerationCenter ...
    + lambda * cfg3.operating.eCenter ...
    - velocityRow(7)) / velocityRow(1);

closedLoopError = [ ...
    errorRow(2), ...
    errorRow(3), ...
    errorRow(3) + errorRow(4), ...
    errorRow(5), errorRow(6), errorRow(7)] ...
    + errorRow(1) * c;

policy.lambda = lambda;
policy.accelerationCenter = accelerationCenter;
policy.inputCoefficient = c;
policy.errorCoefficient = closedLoopError;
end
