function plot_stage3_results( ...
    summary, liftedResults, grid, cfg1, cfg3)
%PLOT_STAGE3_RESULTS Model comparison and candidate RCIS projection.

figure('Color', 'w', 'Position', [100, 100, 1100, 430]);
tiledlayout(1, 2, 'Padding', 'compact', 'TileSpacing', 'compact');

nexttile;
bar(summary.agent, [ ...
    summary.affineInfeasible, summary.liftedInfeasible], 'grouped');
xlabel('Agent');
ylabel('Infeasible grid nodes');
legend({'Affine predictor', 'Lifted predictor'}, ...
    'Location', 'northwest');
title('Offline robust-successor test');
set(gca, 'XGrid', 'on', 'YGrid', 'on');

nexttile;
allMargins = cellfun(@(r) r.bestMargin, ...
    liftedResults, 'UniformOutput', false);
worstAcrossAgents = min(vertcat(allMargins{:}), [], 1);
relativeVelocity = grid.state(2, :) - grid.state(3, :);
scatter(grid.state(1, :), relativeVelocity, 14, ...
    worstAcrossAgents, 'filled');
hold on;
theta = linspace(0, 2 * pi, 400);
L = chol(cfg3.ellipsoid.P, 'lower');
boundary = sqrt(cfg3.ellipsoid.rho) * (L.' \ [cos(theta); sin(theta)]);
plot(cfg3.operating.eCenter + boundary(1, :), ...
    boundary(2, :), 'k-', 'LineWidth', 1.3);
xlabel('Spacing error e');
ylabel('Relative velocity v-v_{ref}');
title(sprintf('Grid-certified ellipsoid, %d agents', cfg1.N));
colorbar;
set(gca, 'XGrid', 'on', 'YGrid', 'on');

exportgraphics(gcf, fullfile(cfg3.resultsDir, ...
    'fig_stage3_grid_certificate.png'), 'Resolution', 180);
close(gcf);
end
