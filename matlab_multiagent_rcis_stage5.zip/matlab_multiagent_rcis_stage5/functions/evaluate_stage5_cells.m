function [bestMargin, bestInput] = evaluate_stage5_cells( ...
    cells, model, envelope, cfg1, cfg3, cfg5)
%EVALUATE_STAGE5_CELLS Find one robust input valid on each complete box.

nCells = size(cells.lower, 2);
nInputs = numel(cfg3.input.uGrid);
bestMargin = -inf(1, nCells);
bestInput = nan(1, nCells);
uGrid = cfg3.input.uGrid(:);
P = cfg3.ellipsoid.P;

for first = 1:cfg5.refinement.stateChunk:nCells
    last = min(first + cfg5.refinement.stateChunk - 1, nCells);
    indices = first:last;
    lower = cells.lower(:, indices);
    upper = cells.upper(:, indices);
    [lower, upper] = tighten_stage5_ellipsoid_box( ...
        lower, upper, cfg3);

    eLower = lower(1, :);
    eUpper = upper(1, :);
    rLower = lower(2, :);
    rUpper = upper(2, :);
    vRefLower = lower(3, :);
    vRefUpper = upper(3, :);
    dLower = lower(4, :);
    dUpper = upper(4, :);

    % Rewrite the predictor in (e,r,v_ref,d) coordinates and compute the
    % exact range of a*r + b*v_ref + c*(r+v_ref)^2 on each rectangle.
    predictionBaseLower = zeros(2, numel(indices));
    predictionBaseUpper = zeros(2, numel(indices));
    for row = 1:2
        [coupledLower, coupledUpper] = ...
            quadratic_coordinate_range( ...
            rLower, rUpper, vRefLower, vRefUpper, ...
            model.M(row, 3), ...
            model.M(row, 3) + model.M(row, 4), ...
            model.M(row, 6));
        eTerms = model.M(row, 2) * [eLower; eUpper];
        dTerms = model.M(row, 5) * [dLower; dUpper];
        predictionBaseLower(row, :) = coupledLower ...
            + min(eTerms, [], 1) + min(dTerms, [], 1) ...
            + model.M(row, 7);
        predictionBaseUpper(row, :) = coupledUpper ...
            + max(eTerms, [], 1) + max(dTerms, [], 1) ...
            + model.M(row, 7);
    end

    inputCoefficient = model.M(:, 1);
    inputContribution = inputCoefficient .* uGrid.';
    predictionLower = cell(2, 1);
    predictionUpper = cell(2, 1);
    for row = 1:2
        predictionLower{row} = inputContribution(row, :).'+ ...
            predictionBaseLower(row, :);
        predictionUpper{row} = inputContribution(row, :).'+ ...
            predictionBaseUpper(row, :);
    end

    errorLower = predictionLower{1} - envelope.beta(1);
    errorUpper = predictionUpper{1} + envelope.beta(1);
    velocityLower = predictionLower{2} - envelope.beta(2);
    velocityUpper = predictionUpper{2} + envelope.beta(2);

    referenceLower = max(vRefLower + ...
        cfg1.Ts * cfg3.operating.aRefMin, ...
        cfg3.operating.vRefMin);
    referenceUpper = min(vRefUpper + ...
        cfg1.Ts * cfg3.operating.aRefMax, ...
        cfg3.operating.vRefMax);
    relativeLower = velocityLower - referenceUpper;
    relativeUpper = velocityUpper - referenceLower;
    shiftedErrorLower = errorLower - cfg3.operating.eCenter;
    shiftedErrorUpper = errorUpper - cfg3.operating.eCenter;

    value11 = quadratic_value( ...
        shiftedErrorLower, relativeLower, P);
    value12 = quadratic_value( ...
        shiftedErrorLower, relativeUpper, P);
    value21 = quadratic_value( ...
        shiftedErrorUpper, relativeLower, P);
    value22 = quadratic_value( ...
        shiftedErrorUpper, relativeUpper, P);
    worstEllipsoidValue = max( ...
        cat(3, value11, value12, value21, value22), [], 3);

    margins = cat(3, ...
        cfg3.ellipsoid.rho - worstEllipsoidValue, ...
        velocityLower - cfg3.operating.vMin, ...
        cfg3.operating.vMax - velocityUpper);
    candidateMargin = min(margins, [], 3);
    [localBestMargin, localBestIndex] = ...
        max(candidateMargin, [], 1);
    bestMargin(indices) = localBestMargin;
    bestInput(indices) = reshape( ...
        uGrid(localBestIndex), 1, []);
end
end

function value = quadratic_value(errorValue, relativeValue, P)
value = P(1, 1) * errorValue.^2 ...
    + 2 * P(1, 2) * errorValue .* relativeValue ...
    + P(2, 2) * relativeValue.^2;
end

function [lowerValue, upperValue] = quadratic_coordinate_range( ...
    rLower, rUpper, vRefLower, vRefUpper, a, b, c)
% Exact extrema of a*r+b*s+c*(r+s)^2 on a rectangle.

rBounds = [rLower; rUpper];
sBounds = [vRefLower; vRefUpper];
values = zeros(8, numel(rLower));
candidate = 0;

for rIndex = 1:2
    for sIndex = 1:2
        candidate = candidate + 1;
        r = rBounds(rIndex, :);
        s = sBounds(sIndex, :);
        values(candidate, :) = ...
            a * r + b * s + c * (r + s).^2;
    end
end

if abs(c) > 100 * eps
    for rIndex = 1:2
        candidate = candidate + 1;
        r = rBounds(rIndex, :);
        s = min(max(-b / (2 * c) - r, ...
            vRefLower), vRefUpper);
        values(candidate, :) = ...
            a * r + b * s + c * (r + s).^2;
    end
    for sIndex = 1:2
        candidate = candidate + 1;
        s = sBounds(sIndex, :);
        r = min(max(-a / (2 * c) - s, ...
            rLower), rUpper);
        values(candidate, :) = ...
            a * r + b * s + c * (r + s).^2;
    end
else
    values(5:8, :) = values(1:4, :);
end

lowerValue = min(values, [], 1);
upperValue = max(values, [], 1);
end
