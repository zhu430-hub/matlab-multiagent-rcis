function [bestMargin, bestInput] = evaluate_stage5_cells( ...
    cells, model, envelope, cfg1, cfg3, cfg5)
%EVALUATE_STAGE5_CELLS Find one robust input valid on each complete box.

nCells = size(cells.lower, 2);
nInputs = numel(cfg3.input.uGrid);
bestMargin = -inf(1, nCells);
bestInput = nan(1, nCells);
uGrid = cfg3.input.uGrid(:);
P = cfg3.ellipsoid.P;

for first = 1:cfg5.refinement.stateChunk:nCells
    last = min(first + cfg5.refinement.stateChunk - 1, nCells);
    indices = first:last;
    lower = cells.lower(:, indices);
    upper = cells.upper(:, indices);

    eLower = lower(1, :);
    eUpper = upper(1, :);
    vLower = lower(2, :) + lower(3, :);
    vUpper = upper(2, :) + upper(3, :);
    vRefLower = lower(3, :);
    vRefUpper = upper(3, :);
    dLower = lower(4, :);
    dUpper = upper(4, :);

    % Rewrite M_v*v + M_vref*v_ref using v = r + v_ref before
    % interval propagation.  This preserves the dominant cancellation in
    % the spacing-error and relative-velocity dynamics.
    featureLower = [ ...
        eLower; lower(2, :); vRefLower; dLower; ...
        vLower.^2; ones(1, numel(indices))];
    featureUpper = [ ...
        eUpper; upper(2, :); vRefUpper; dUpper; ...
        vUpper.^2; ones(1, numel(indices))];

    stateMatrix = [ ...
        model.M(:, 2), ...
        model.M(:, 3), ...
        model.M(:, 3) + model.M(:, 4), ...
        model.M(:, 5:7)];
    positivePart = max(stateMatrix, 0);
    negativePart = min(stateMatrix, 0);
    predictionBaseLower = positivePart * featureLower ...
        + negativePart * featureUpper;
    predictionBaseUpper = positivePart * featureUpper ...
        + negativePart * featureLower;

    inputCoefficient = model.M(:, 1);
    inputContribution = inputCoefficient .* uGrid.';
    predictionLower = cell(2, 1);
    predictionUpper = cell(2, 1);
    for row = 1:2
        predictionLower{row} = inputContribution(row, :).'+ ...
            predictionBaseLower(row, :);
        predictionUpper{row} = inputContribution(row, :).'+ ...
            predictionBaseUpper(row, :);
    end

    errorLower = predictionLower{1} - envelope.beta(1);
    errorUpper = predictionUpper{1} + envelope.beta(1);
    velocityLower = predictionLower{2} - envelope.beta(2);
    velocityUpper = predictionUpper{2} + envelope.beta(2);

    referenceLower = max(vRefLower + ...
        cfg1.Ts * cfg3.operating.aRefMin, ...
        cfg3.operating.vRefMin);
    referenceUpper = min(vRefUpper + ...
        cfg1.Ts * cfg3.operating.aRefMax, ...
        cfg3.operating.vRefMax);
    relativeLower = velocityLower - referenceUpper;
    relativeUpper = velocityUpper - referenceLower;
    shiftedErrorLower = errorLower - cfg3.operating.eCenter;
    shiftedErrorUpper = errorUpper - cfg3.operating.eCenter;

    value11 = quadratic_value( ...
        shiftedErrorLower, relativeLower, P);
    value12 = quadratic_value( ...
        shiftedErrorLower, relativeUpper, P);
    value21 = quadratic_value( ...
        shiftedErrorUpper, relativeLower, P);
    value22 = quadratic_value( ...
        shiftedErrorUpper, relativeUpper, P);
    worstEllipsoidValue = max( ...
        cat(3, value11, value12, value21, value22), [], 3);

    margins = cat(3, ...
        cfg3.ellipsoid.rho - worstEllipsoidValue, ...
        velocityLower - cfg3.operating.vMin, ...
        cfg3.operating.vMax - velocityUpper);
    candidateMargin = min(margins, [], 3);
    [localBestMargin, localBestIndex] = ...
        max(candidateMargin, [], 1);
    bestMargin(indices) = localBestMargin;
    bestInput(indices) = reshape( ...
        uGrid(localBestIndex), 1, []);
end
end

function value = quadratic_value(errorValue, relativeValue, P)
value = P(1, 1) * errorValue.^2 ...
    + 2 * P(1, 2) * errorValue .* relativeValue ...
    + P(2, 2) * relativeValue.^2;
end
