function beta = evaluate_error_bound(qMeasured, envelope, cfg)
%EVALUATE_ERROR_BOUND Evaluate beta(w) at measured operating points.

xiMeasured = normalize_operating_point(qMeasured, cfg);
augmentedNorm = sqrt(sum(xiMeasured.^2, 1) + 1);

constantMargin = ...
    (envelope.lipschitz + envelope.kappa) * envelope.epsilonCover ...
    + envelope.kappa * envelope.deltaXi ...
    + envelope.etaNoise;

beta = envelope.kappa .* augmentedNorm + constantMargin;
end
