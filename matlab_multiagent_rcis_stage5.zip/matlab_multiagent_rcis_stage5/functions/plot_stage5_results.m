function plot_stage5_results(summary, cfg5)
%PLOT_STAGE5_RESULTS Complexity of the adaptive continuous certificate.

figure('Color', 'w', 'Position', [100, 100, 950, 420]);
tiledlayout(1, 2, 'Padding', 'compact', 'TileSpacing', 'compact');

nexttile;
bar(summary.agent, summary.certifiedLeaves);
xlabel('Agent');
ylabel('Certified leaf cells');
set(gca, 'XGrid', 'on', 'YGrid', 'on');

nexttile;
bar(summary.agent, summary.maximumDepth);
xlabel('Agent');
ylabel('Maximum bisection depth');
set(gca, 'XGrid', 'on', 'YGrid', 'on');

exportgraphics(gcf, fullfile(cfg5.resultsDir, ...
    'fig_stage5_continuous_certificate.png'), 'Resolution', 180);
close(gcf);
end
