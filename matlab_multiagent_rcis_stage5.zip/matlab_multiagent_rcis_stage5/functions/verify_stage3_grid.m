function result = verify_stage3_grid( ...
    grid, model, envelope, modelType, cfg1, cfg3)
%VERIFY_STAGE3_GRID Check existence of a robust successor input at each node.

nStates = grid.includedNodeCount;
nInputs = numel(cfg3.input.uGrid);
bestMargin = -inf(1, nStates);
bestInput = nan(1, nStates);
P = cfg3.ellipsoid.P;
rho = cfg3.ellipsoid.rho;
eCenter = cfg3.operating.eCenter;

for first = 1:cfg3.computation.stateChunk:nStates
    last = min(first + cfg3.computation.stateChunk - 1, nStates);
    indices = first:last;
    nLocal = numel(indices);
    state = grid.state(:, indices);

    q = zeros(5, nInputs * nLocal);
    q(1, :) = repmat(cfg3.input.uGrid, 1, nLocal);
    for row = 1:4
        q(row + 1, :) = repelem(state(row, :), nInputs);
    end

    switch modelType
        case 'lifted'
            prediction = model.M * lifted_features(q);
            beta = evaluate_lifted_error_bound(q, envelope);
        case 'affine'
            prediction = model.M * [q; ones(1, size(q, 2))];
            beta = evaluate_error_bound(q, envelope, cfg1);
        otherwise
            error('Unknown Stage 3 model type.');
    end

    errorLower = reshape( ...
        prediction(1, :) - beta(1, :), nInputs, nLocal);
    errorUpper = reshape( ...
        prediction(1, :) + beta(1, :), nInputs, nLocal);
    velocityLower = reshape( ...
        prediction(2, :) - beta(2, :), nInputs, nLocal);
    velocityUpper = reshape( ...
        prediction(2, :) + beta(2, :), nInputs, nLocal);

    referenceLower = max( ...
        state(3, :) + cfg1.Ts * cfg3.operating.aRefMin, ...
        cfg3.operating.vRefMin);
    referenceUpper = min( ...
        state(3, :) + cfg1.Ts * cfg3.operating.aRefMax, ...
        cfg3.operating.vRefMax);
    relativeLower = velocityLower - referenceUpper;
    relativeUpper = velocityUpper - referenceLower;
    shiftedErrorLower = errorLower - eCenter;
    shiftedErrorUpper = errorUpper - eCenter;

    value11 = quadratic_value( ...
        shiftedErrorLower, relativeLower, P);
    value12 = quadratic_value( ...
        shiftedErrorLower, relativeUpper, P);
    value21 = quadratic_value( ...
        shiftedErrorUpper, relativeLower, P);
    value22 = quadratic_value( ...
        shiftedErrorUpper, relativeUpper, P);
    worstEllipsoidValue = max( ...
        cat(3, value11, value12, value21, value22), [], 3);

    margins = cat(3, ...
        rho - worstEllipsoidValue, ...
        velocityLower - cfg3.operating.vMin, ...
        cfg3.operating.vMax - velocityUpper);
    candidateMargin = min(margins, [], 3);
    [localBestMargin, localBestIndex] = max(candidateMargin, [], 1);

    bestMargin(indices) = localBestMargin;
    bestInput(indices) = cfg3.input.uGrid(localBestIndex);
end

result.bestMargin = bestMargin;
result.bestInput = bestInput;
result.feasible = bestMargin >= -cfg3.validation.tolerance;
result.feasibleCount = sum(result.feasible);
result.infeasibleCount = sum(~result.feasible);
result.feasibilityRate = mean(result.feasible);
result.worstMargin = min(bestMargin);
[~, result.worstNodeIndex] = min(bestMargin);
result.worstState = grid.state(:, result.worstNodeIndex);
end

function value = quadratic_value(errorValue, relativeValue, P)
value = P(1, 1) * errorValue.^2 ...
    + 2 * P(1, 2) * errorValue .* relativeValue ...
    + P(2, 2) * relativeValue.^2;
end
