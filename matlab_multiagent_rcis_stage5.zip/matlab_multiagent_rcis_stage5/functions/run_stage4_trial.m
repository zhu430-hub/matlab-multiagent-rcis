function result = run_stage4_trial( ...
    useFilter, scenario, trialIndex, models, envelopes, cfg1, cfg3, cfg4)
%RUN_STAGE4_TRIAL Simulate one coupled platoon trial.

rng(cfg1.randomSeed + 40000 + 1000 * trialIndex + ...
    round(100 * scenario.dragMismatch) + ...
    round(1000 * scenario.leaderActualAccelMax), 'twister');

nSteps = cfg4.nSteps;
N = cfg1.N;
leaderVelocity = zeros(1, nSteps + 1);
leaderVelocity(1) = cfg4.leader.initialVelocity;
leaderAcceleration = zeros(1, nSteps);

for k = 1:nSteps
    if mod(k - 1, cfg4.leader.segmentSteps) == 0
        segmentAcceleration = cfg4.leader.declaredAccelMin + rand * ...
            (scenario.leaderActualAccelMax - cfg4.leader.declaredAccelMin);
    end
    unconstrainedLeaderNext = leaderVelocity(k) + ...
        cfg1.Ts * segmentAcceleration;
    leaderVelocity(k + 1) = min(max(unconstrainedLeaderNext, ...
        cfg3.operating.vRefMin), cfg3.operating.vRefMax);
    leaderAcceleration(k) = ...
        (leaderVelocity(k + 1) - leaderVelocity(k)) / cfg1.Ts;
end

errorState = zeros(N, nSteps + 1);
velocity = zeros(N, nSteps + 1);
errorState(:, 1) = cfg3.operating.eCenter + cfg4.initial.errorOffset;
predecessorInitial = [leaderVelocity(1); zeros(N - 1, 1)];
for i = 1:N
    if i > 1
        predecessorInitial(i) = velocity(i - 1, 1);
    end
    velocity(i, 1) = predecessorInitial(i) + ...
        cfg4.initial.relativeVelocity(i);
end

recursiveFeasible = true(N, nSteps);
filterActive = false(N, nSteps);
certificateMargin = nan(N, nSteps);
ellipsoidViolation = false(N, nSteps);
velocityViolation = false(N, nSteps);
inputViolation = false(N, nSteps);
certificateEscape = false(N, nSteps);
leaderContractViolation = false(1, nSteps);
maximumResidualRatio = 0;

actualDrag = cfg1.plant.drag .* (1 + scenario.dragMismatch);

for k = 1:nSteps
    disturbance = 0.15 * sin( ...
        0.37 * k + 0.61 * (1:N).' + 0.13 * trialIndex);
    predecessorCurrent = [leaderVelocity(k); velocity(1:N-1, k)];
    predecessorNext = [leaderVelocity(k + 1); nan(N - 1, 1)];

    leaderLower = max(leaderVelocity(k) + ...
        cfg1.Ts * cfg4.leader.declaredAccelMin, ...
        cfg3.operating.vRefMin);
    leaderUpper = min(leaderVelocity(k) + ...
        cfg1.Ts * cfg4.leader.declaredAccelMax, ...
        cfg3.operating.vRefMax);
    leaderContractViolation(k) = leaderVelocity(k + 1) < ...
        leaderLower - cfg4.validation.tolerance ...
        || leaderVelocity(k + 1) > ...
        leaderUpper + cfg4.validation.tolerance;
    predecessorCertificate.lower = leaderLower;
    predecessorCertificate.upper = leaderUpper;

    selectedInput = zeros(N, 1);
    outgoingLower = nan(N, 1);
    outgoingUpper = nan(N, 1);

    for i = 1:N
        qTrue = [0; errorState(i, k); velocity(i, k); ...
            predecessorCurrent(i); disturbance(i)];
        qMeasured = measure_operating_point(qTrue, cfg1);

        dragCompensation = cfg1.plant.drag(i) * ...
            qMeasured(3) * abs(qMeasured(3)) - qMeasured(5);
        uNominal = dragCompensation ...
            + cfg4.nominal.kRelativeVelocity * ...
            (qMeasured(4) - qMeasured(3)) ...
            - cfg4.nominal.kSpacing * ...
            (qMeasured(2) - cfg3.operating.eCenter);
        uNominal = min(max(uNominal, cfg1.input.umin), cfg1.input.umax);

        if useFilter
            [selectedInput(i), certificate, diagnostics] = ...
                stage4_distributed_filter( ...
                qMeasured, uNominal, models{i}, envelopes{i}, ...
                predecessorCertificate.lower, ...
                predecessorCertificate.upper, cfg3, cfg4);
            recursiveFeasible(i, k) = diagnostics.recursiveFeasible;
            filterActive(i, k) = diagnostics.filterActive;
            certificateMargin(i, k) = diagnostics.minimumMargin;
            outgoingLower(i) = certificate.lower;
            outgoingUpper(i) = certificate.upper;
            predecessorCertificate = certificate;
        else
            selectedInput(i) = uNominal;
        end

        qMeasured(1) = selectedInput(i);
        prediction = models{i}.M * lifted_features(qMeasured);
        beta = evaluate_lifted_error_bound(qMeasured, envelopes{i});
        qTrue(1) = selectedInput(i);
        xNextTrue = vehicle_step_mismatch( ...
            qTrue, actualDrag(i), cfg1.Ts);
        xNextMeasured = measure_successor(xNextTrue, cfg1);
        maximumResidualRatio = max(maximumResidualRatio, ...
            max(abs(xNextMeasured - prediction) ./ beta));

        errorState(i, k + 1) = xNextTrue(1);
        velocity(i, k + 1) = xNextTrue(2);
    end

    predecessorNext(2:N) = velocity(1:N-1, k + 1);
    for i = 1:N
        relativeNext = velocity(i, k + 1) - predecessorNext(i);
        shiftedError = errorState(i, k + 1) - ...
            cfg3.operating.eCenter;
        ellipsoidValue = [shiftedError, relativeNext] * ...
            cfg3.ellipsoid.P * [shiftedError; relativeNext];
        ellipsoidViolation(i, k) = ellipsoidValue > ...
            cfg3.ellipsoid.rho + cfg4.validation.tolerance;
        velocityViolation(i, k) = velocity(i, k + 1) < ...
            cfg3.operating.vMin - cfg4.validation.tolerance ...
            || velocity(i, k + 1) > ...
            cfg3.operating.vMax + cfg4.validation.tolerance;
        inputViolation(i, k) = selectedInput(i) < ...
            cfg1.input.umin - cfg4.validation.tolerance ...
            || selectedInput(i) > ...
            cfg1.input.umax + cfg4.validation.tolerance;
        if useFilter
            certificateEscape(i, k) = velocity(i, k + 1) < ...
                outgoingLower(i) - cfg4.validation.tolerance ...
                || velocity(i, k + 1) > ...
                outgoingUpper(i) + cfg4.validation.tolerance;
        end
    end
end

result.useFilter = useFilter;
result.scenario = scenario.name;
if useFilter
    result.recursiveFeasibilityRate = mean(recursiveFeasible(:));
    result.filterActivationRate = mean(filterActive(:));
    result.minimumCertificateMargin = min(certificateMargin(:));
else
    result.recursiveFeasibilityRate = nan;
    result.filterActivationRate = nan;
    result.minimumCertificateMargin = nan;
end
result.ellipsoidViolations = sum(ellipsoidViolation(:));
result.velocityViolations = sum(velocityViolation(:));
result.inputViolations = sum(inputViolation(:));
result.certificateEscapes = sum(certificateEscape(:));
result.leaderContractViolations = sum(leaderContractViolation(:));
result.maximumResidualRatio = maximumResidualRatio;
result.success = result.ellipsoidViolations == 0 ...
    && result.velocityViolations == 0 ...
    && result.inputViolations == 0 ...
    && (~useFilter || (all(recursiveFeasible(:)) ...
        && result.certificateEscapes == 0));
end

function qMeasured = measure_operating_point(qTrue, cfg)
radius = [0; cfg.noise.x; cfg.noise.z];
qMeasured = qTrue + (2 * rand(size(qTrue)) - 1) .* radius;
end

function xMeasured = measure_successor(xTrue, cfg)
xMeasured = xTrue + ...
    (2 * rand(size(xTrue)) - 1) .* cfg.noise.x;
end
