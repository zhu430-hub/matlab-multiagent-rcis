function [qMeasured, xNextMeasured, noise] = add_measurement_noise( ...
    qTrue, xNextTrue, cfg)
%ADD_MEASUREMENT_NOISE Add independent bounded measurement errors.

sampleCount = size(qTrue, 2);

vx = cfg.noise.x .* (2 * rand(cfg.dim.x, sampleCount) - 1);
vz = cfg.noise.z .* (2 * rand(cfg.dim.z, sampleCount) - 1);
vxNext = cfg.noise.x .* (2 * rand(cfg.dim.x, sampleCount) - 1);

qMeasured = qTrue;
qMeasured(2:3, :) = qMeasured(2:3, :) + vx;
qMeasured(4:5, :) = qMeasured(4:5, :) + vz;
xNextMeasured = xNextTrue + vxNext;

noise.vx = vx;
noise.vz = vz;
noise.vxNext = vxNext;
end
