function xNext = vehicle_step_true(q, cfg, agentIndex)
%VEHICLE_STEP_TRUE Simulation plant unknown to the data-driven controller.
%
% q is 5-by-M and ordered as [u; e; v; v_ref; d].

u = q(1, :);
e = q(2, :);
v = q(3, :);
vRef = q(4, :);
d = q(5, :);

Ts = cfg.Ts;
c = cfg.plant.drag(agentIndex);

acceleration = u - c .* v .* abs(v) + d;

eNext = e + Ts .* (v - vRef) + 0.5 * Ts^2 .* acceleration;
vNext = v + Ts .* acceleration;

xNext = [eNext; vNext];
end
