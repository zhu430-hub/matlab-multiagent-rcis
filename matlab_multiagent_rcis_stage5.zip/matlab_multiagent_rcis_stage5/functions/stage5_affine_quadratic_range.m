function [lowerValue, upperValue] = ...
    stage5_affine_quadratic_range(lower, upper, coefficient)
%STAGE5_AFFINE_QUADRATIC_RANGE Exact range of the Stage 5 policy form.
%
% coefficient multiplies [e, r, v_ref, d, (r+v_ref)^2, 1].

eTerms = coefficient(1) * [lower(1, :); upper(1, :)];
dTerms = coefficient(4) * [lower(4, :); upper(4, :)];
[coupledLower, coupledUpper] = quadratic_coordinate_range( ...
    lower(2, :), upper(2, :), ...
    lower(3, :), upper(3, :), ...
    coefficient(2), coefficient(3), coefficient(5));

lowerValue = min(eTerms, [], 1) + min(dTerms, [], 1) ...
    + coupledLower + coefficient(6);
upperValue = max(eTerms, [], 1) + max(dTerms, [], 1) ...
    + coupledUpper + coefficient(6);
end

function [lowerValue, upperValue] = quadratic_coordinate_range( ...
    rLower, rUpper, vRefLower, vRefUpper, a, b, c)

rBounds = [rLower; rUpper];
sBounds = [vRefLower; vRefUpper];
values = zeros(8, numel(rLower));
candidate = 0;

for rIndex = 1:2
    for sIndex = 1:2
        candidate = candidate + 1;
        r = rBounds(rIndex, :);
        s = sBounds(sIndex, :);
        values(candidate, :) = ...
            a * r + b * s + c * (r + s).^2;
    end
end

if abs(c) > 100 * eps
    for rIndex = 1:2
        candidate = candidate + 1;
        r = rBounds(rIndex, :);
        s = min(max(-b / (2 * c) - r, ...
            vRefLower), vRefUpper);
        values(candidate, :) = ...
            a * r + b * s + c * (r + s).^2;
    end
    for sIndex = 1:2
        candidate = candidate + 1;
        s = sBounds(sIndex, :);
        r = min(max(-a / (2 * c) - s, ...
            rLower), rUpper);
        values(candidate, :) = ...
            a * r + b * s + c * (r + s).^2;
    end
else
    values(5:8, :) = values(1:4, :);
end

lowerValue = min(values, [], 1);
upperValue = max(values, [], 1);
end
