function xi = normalize_operating_point(q, cfg)
%NORMALIZE_OPERATING_POINT Map the physical box to [-1,1]^n.

xi = 2 .* (q - cfg.range.lower) ./ ...
    (cfg.range.upper - cfg.range.lower) - 1;
end
