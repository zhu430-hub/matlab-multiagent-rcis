function [tightLower, tightUpper] = ...
    tighten_stage5_ellipsoid_box(lower, upper, cfg3)
%TIGHTEN_STAGE5_ELLIPSOID_BOX Bound each box/ellipsoid intersection.
%
% The returned rectangle contains the complete intersection but removes
% coordinate ranges that cannot occur inside the candidate ellipsoid.

P = cfg3.ellipsoid.P;
rho = cfg3.ellipsoid.rho;
xLower = lower(1, :) - cfg3.operating.eCenter;
xUpper = upper(1, :) - cfg3.operating.eCenter;
yLower = lower(2, :);
yUpper = upper(2, :);
n = size(lower, 2);

xCandidate = zeros(5, n);
yCandidate = zeros(5, n);

xCandidate(1, :) = xLower;
yCandidate(1, :) = min(max( ...
    -(P(1, 2) / P(2, 2)) .* xLower, yLower), yUpper);
xCandidate(2, :) = xUpper;
yCandidate(2, :) = min(max( ...
    -(P(1, 2) / P(2, 2)) .* xUpper, yLower), yUpper);
yCandidate(3, :) = yLower;
xCandidate(3, :) = min(max( ...
    -(P(1, 2) / P(1, 1)) .* yLower, xLower), xUpper);
yCandidate(4, :) = yUpper;
xCandidate(4, :) = min(max( ...
    -(P(1, 2) / P(1, 1)) .* yUpper, xLower), xUpper);

containsOrigin = xLower <= 0 & xUpper >= 0 ...
    & yLower <= 0 & yUpper >= 0;
xCandidate(5, :) = 0;
yCandidate(5, :) = 0;
candidateValue = quadratic_value(xCandidate, yCandidate, P);
candidateValue(5, ~containsOrigin) = inf;
[minimumValue, minimumIndex] = min(candidateValue, [], 1);
linearIndex = sub2ind(size(xCandidate), ...
    minimumIndex, 1:n);
xStar = xCandidate(linearIndex);
yStar = yCandidate(linearIndex);

% Cells are prefiltered for intersection.  Retaining an unchanged box is
% safe for a tolerance-only tangency reported just outside rho.
hasFeasiblePoint = minimumValue <= rho;
iterations = 30;

leftValue = minimum_at_fixed_x(xLower, yLower, yUpper, P);
needsLeftTightening = hasFeasiblePoint & leftValue > rho;
lo = xLower;
hi = xStar;
for k = 1:iterations
    midpoint = 0.5 * (lo + hi);
    feasible = minimum_at_fixed_x( ...
        midpoint, yLower, yUpper, P) <= rho;
    hi(needsLeftTightening & feasible) = ...
        midpoint(needsLeftTightening & feasible);
    lo(needsLeftTightening & ~feasible) = ...
        midpoint(needsLeftTightening & ~feasible);
end
xLower(needsLeftTightening) = lo(needsLeftTightening);

rightValue = minimum_at_fixed_x(xUpper, yLower, yUpper, P);
needsRightTightening = hasFeasiblePoint & rightValue > rho;
lo = xStar;
hi = xUpper;
for k = 1:iterations
    midpoint = 0.5 * (lo + hi);
    feasible = minimum_at_fixed_x( ...
        midpoint, yLower, yUpper, P) <= rho;
    lo(needsRightTightening & feasible) = ...
        midpoint(needsRightTightening & feasible);
    hi(needsRightTightening & ~feasible) = ...
        midpoint(needsRightTightening & ~feasible);
end
xUpper(needsRightTightening) = hi(needsRightTightening);

lowerValue = minimum_at_fixed_y(yLower, xLower, xUpper, P);
needsLowerTightening = hasFeasiblePoint & lowerValue > rho;
lo = yLower;
hi = yStar;
for k = 1:iterations
    midpoint = 0.5 * (lo + hi);
    feasible = minimum_at_fixed_y( ...
        midpoint, xLower, xUpper, P) <= rho;
    hi(needsLowerTightening & feasible) = ...
        midpoint(needsLowerTightening & feasible);
    lo(needsLowerTightening & ~feasible) = ...
        midpoint(needsLowerTightening & ~feasible);
end
yLower(needsLowerTightening) = lo(needsLowerTightening);

upperValue = minimum_at_fixed_y(yUpper, xLower, xUpper, P);
needsUpperTightening = hasFeasiblePoint & upperValue > rho;
lo = yStar;
hi = yUpper;
for k = 1:iterations
    midpoint = 0.5 * (lo + hi);
    feasible = minimum_at_fixed_y( ...
        midpoint, xLower, xUpper, P) <= rho;
    lo(needsUpperTightening & feasible) = ...
        midpoint(needsUpperTightening & feasible);
    hi(needsUpperTightening & ~feasible) = ...
        midpoint(needsUpperTightening & ~feasible);
end
yUpper(needsUpperTightening) = hi(needsUpperTightening);

tightLower = lower;
tightUpper = upper;
tightLower(1, :) = xLower + cfg3.operating.eCenter;
tightUpper(1, :) = xUpper + cfg3.operating.eCenter;
tightLower(2, :) = yLower;
tightUpper(2, :) = yUpper;
end

function value = minimum_at_fixed_x(x, yLower, yUpper, P)
y = min(max(-(P(1, 2) / P(2, 2)) .* x, ...
    yLower), yUpper);
value = quadratic_value(x, y, P);
end

function value = minimum_at_fixed_y(y, xLower, xUpper, P)
x = min(max(-(P(1, 2) / P(1, 1)) .* y, ...
    xLower), xUpper);
value = quadratic_value(x, y, P);
end

function value = quadratic_value(x, y, P)
value = P(1, 1) * x.^2 ...
    + 2 * P(1, 2) * x .* y ...
    + P(2, 2) * y.^2;
end
