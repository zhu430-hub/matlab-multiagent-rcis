function lipschitz = lifted_residual_lipschitz_bound( ...
    model, cfg, agentIndex)
%LIFTED_RESIDUAL_LIPSCHITZ_BOUND Exact simulation-side derivative bound.
%
% The true derivative is used only to certify the numerical experiment,
% never by the fitted predictor or online input search.

Ts = cfg.Ts;
c = cfg.plant.drag(agentIndex);
scale = 0.5 * (cfg.range.upper - cfg.range.lower);
scaleMatrix = diag(scale);
velocityEndpoints = [cfg.range.lower(3), cfg.range.upper(3)];
gradientNorms = zeros(cfg.dim.x, numel(velocityEndpoints));

for k = 1:numel(velocityEndpoints)
    v = velocityEndpoints(k);
    Jf = [ ...
        0.5 * Ts^2, 1, Ts - Ts^2 * c * v, -Ts, 0.5 * Ts^2; ...
        Ts,          0, 1 - 2 * Ts * c * v, 0, Ts];

    Jphi = [ ...
        1, 0, 0,     0, 0; ...
        0, 1, 0,     0, 0; ...
        0, 0, 1,     0, 0; ...
        0, 0, 0,     1, 0; ...
        0, 0, 0,     0, 1; ...
        0, 0, 2 * v, 0, 0; ...
        0, 0, 0,     0, 0];

    normalizedJacobian = (Jf - model.M * Jphi) * scaleMatrix;
    gradientNorms(:, k) = sqrt(sum(normalizedJacobian.^2, 2));
end

lipschitz = max(gradientNorms, [], 2);
end
