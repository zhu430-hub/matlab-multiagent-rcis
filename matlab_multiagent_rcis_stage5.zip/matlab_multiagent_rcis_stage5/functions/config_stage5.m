function cfg5 = config_stage5(cfg1, cfg3, projectRoot)
%CONFIG_STAGE5 Adaptive interval certificate for the continuous RCIS domain.

cfg5.partition.nErrorCells = cfg3.grid.nError - 1;
cfg5.partition.nRelativeVelocityCells = ...
    cfg3.grid.nRelativeVelocity - 1;
cfg5.partition.nReferenceVelocityCells = ...
    cfg3.grid.nReferenceVelocity - 1;
cfg5.partition.nDisturbanceCells = 6;

cfg5.refinement.maxDepth = 16;
cfg5.refinement.maxPendingCells = 6e6;
cfg5.refinement.stateChunk = 128;
cfg5.refinement.feasibilityTolerance = 1e-10;
cfg5.refinement.targetWidth = [0.03; 0.002; 0.04; 0.0125];

cfg5.resultsDir = fullfile(projectRoot, 'results_stage5');
end
