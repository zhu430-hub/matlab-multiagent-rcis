function [uSelected, certificate, diagnostics] = ...
    stage4_distributed_filter(q, uNominal, model, envelope, ...
    predecessorLower, predecessorUpper, cfg3, cfg4)
%STAGE4_DISTRIBUTED_FILTER One-hop lifted robust ellipsoid filter.

uGrid = cfg4.filter.uGrid;
nInputs = numel(uGrid);
qCandidate = repmat(q, 1, nInputs);
qCandidate(1, :) = uGrid;

prediction = model.M * lifted_features(qCandidate);
beta = evaluate_lifted_error_bound(qCandidate, envelope);
errorLower = prediction(1, :) - beta(1, :);
errorUpper = prediction(1, :) + beta(1, :);
velocityLower = prediction(2, :) - beta(2, :);
velocityUpper = prediction(2, :) + beta(2, :);
relativeLower = velocityLower - predecessorUpper;
relativeUpper = velocityUpper - predecessorLower;

P = cfg3.ellipsoid.P;
shiftedLower = errorLower - cfg3.operating.eCenter;
shiftedUpper = errorUpper - cfg3.operating.eCenter;
values = [ ...
    quadratic_value(shiftedLower, relativeLower, P); ...
    quadratic_value(shiftedLower, relativeUpper, P); ...
    quadratic_value(shiftedUpper, relativeLower, P); ...
    quadratic_value(shiftedUpper, relativeUpper, P)];

margins = [ ...
    cfg3.ellipsoid.rho - max(values, [], 1); ...
    velocityLower - cfg3.operating.vMin; ...
    cfg3.operating.vMax - velocityUpper];
minimumMargin = min(margins, [], 1);
feasible = minimumMargin >= -cfg4.filter.feasibilityTolerance;
feasibleIndices = find(feasible);

if isempty(feasibleIndices)
    [~, selectedIndex] = max(minimumMargin);
    diagnostics.recursiveFeasible = false;
else
    [~, localIndex] = min((uGrid(feasibleIndices) - uNominal).^2);
    selectedIndex = feasibleIndices(localIndex);
    diagnostics.recursiveFeasible = true;
end

uSelected = uGrid(selectedIndex);
certificate.lower = velocityLower(selectedIndex);
certificate.upper = velocityUpper(selectedIndex);
diagnostics.minimumMargin = minimumMargin(selectedIndex);
diagnostics.filterActive = abs(uSelected - uNominal) > 0.5 * ...
    max(diff(uGrid));
diagnostics.feasibleInputCount = numel(feasibleIndices);
end

function value = quadratic_value(errorValue, relativeValue, P)
value = P(1, 1) * errorValue.^2 ...
    + 2 * P(1, 2) * errorValue .* relativeValue ...
    + P(2, 2) * relativeValue.^2;
end
