function cfg = config_stage1(projectRoot)
%CONFIG_STAGE1 Central configuration for the Stage 1 experiment.

cfg.randomSeed = 20260724;
cfg.N = 5;
cfg.Ts = 0.10;

% Heterogeneous unknown drag coefficients used only by the simulation plant.
cfg.plant.drag = linspace(0.012, 0.028, cfg.N);

% Physical operating box, ordered as q = [u; e; v; v_ref; d].
cfg.range.lower = [-2.00; -4.00; 0.00; 1.00; -0.15];
cfg.range.upper = [ 1.50;  4.00; 8.00; 7.00;  0.15];

cfg.input.umin = cfg.range.lower(1);
cfg.input.umax = cfg.range.upper(1);

cfg.state.eMax = 4.0;
cfg.state.vMin = 0.0;
cfg.state.vMax = 8.0;

% Bounded measurement-noise radii.
cfg.noise.x = [0.020; 0.010];
cfg.noise.z = [0.010; 0.005];

cfg.data.nTrain = 800;
cfg.data.nGridPerDimension = 5;
cfg.data.nTest = 5000;
cfg.data.sigmaMinRequired = 1e-6;

cfg.validation.tolerance = 1e-9;

cfg.dim.u = 1;
cfg.dim.x = 2;
cfg.dim.z = 2;
cfg.dim.q = 5;
cfg.dim.w = 6;

cfg.resultsDir = fullfile(projectRoot, 'results');
end
