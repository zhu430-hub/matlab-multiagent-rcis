function summary = build_stage3_summary( ...
    affineResults, liftedResults, validation, liftedModels, grid, cfg1)
%BUILD_STAGE3_SUMMARY Per-agent certificate and model-quality table.

agent = (1:cfg1.N).';
gridNodes = repmat(grid.includedNodeCount, cfg1.N, 1);
affineInfeasible = zeros(cfg1.N, 1);
liftedInfeasible = zeros(cfg1.N, 1);
affineWorstMargin = zeros(cfg1.N, 1);
liftedWorstMargin = zeros(cfg1.N, 1);
liftedValidationRatio = zeros(cfg1.N, 1);
liftedSigmaMin = zeros(cfg1.N, 1);

for i = 1:cfg1.N
    affineInfeasible(i) = affineResults{i}.infeasibleCount;
    liftedInfeasible(i) = liftedResults{i}.infeasibleCount;
    affineWorstMargin(i) = affineResults{i}.worstMargin;
    liftedWorstMargin(i) = liftedResults{i}.worstMargin;
    liftedValidationRatio(i) = validation{i}.maximumRatio;
    liftedSigmaMin(i) = liftedModels{i}.sigmaMin;
end

summary = table( ...
    agent, gridNodes, affineInfeasible, liftedInfeasible, ...
    affineWorstMargin, liftedWorstMargin, ...
    liftedValidationRatio, liftedSigmaMin);
end
