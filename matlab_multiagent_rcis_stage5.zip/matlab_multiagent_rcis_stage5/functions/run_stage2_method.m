function result = run_stage2_method( ...
    methodName, models, envelopes, leader, cfg1, cfg2)
%RUN_STAGE2_METHOD Simulate nominal or distributed DD-RCIS control.

N = cfg1.N;
K = numel(cfg2.time);
nSteps = cfg2.nSteps;

x = zeros(cfg1.dim.x, N, K);
x(1, :, 1) = cfg2.initial.error.';
x(2, :, 1) = cfg2.initial.velocity.';

u = zeros(N, nSteps);
uNominalHistory = zeros(N, nSteps);
disturbance = zeros(N, nSteps);
recursiveFeasible = false(N, nSteps);
filterActive = false(N, nSteps);
feasibleCount = zeros(N, nSteps);
certificateMargin = zeros(N, nSteps);
predictionRatio = zeros(cfg1.dim.x, N, nSteps);
actualBarrier = zeros(N, K);

actualBarrier(:, 1) = evaluate_actual_barrier( ...
    x(:, :, 1), leader.velocity(1), cfg2);

useSafetyFilter = strcmp(methodName, 'Distributed DD-RCIS');

for k = 1:nSteps
    time = cfg2.time(k);
    disturbance(:, k) = cfg2.disturbance.amplitude .* sin( ...
        cfg2.disturbance.frequency * time + cfg2.disturbance.phase);

    xNext = zeros(cfg1.dim.x, N);

    % One-hop front-to-back message: a certified lower bound on the
    % predecessor's next velocity.
    predecessorVelocityLower = leader.velocity(k + 1);

    for i = 1:N
        if i == 1
            predecessorVelocity = leader.velocity(k);
        else
            predecessorVelocity = x(2, i - 1, k);
        end

        q = [ ...
            0; ...
            x(1, i, k); ...
            x(2, i, k); ...
            predecessorVelocity; ...
            disturbance(i, k)];

        uNominal = cfg2.nominal.kSpeed * ...
            (cfg2.nominal.desiredSpeed - q(3)) ...
            - cfg2.nominal.kError * q(2) ...
            + cfg1.plant.drag(i) * q(3) * abs(q(3));
        uNominal = min(max( ...
            uNominal, cfg1.input.umin), cfg1.input.umax);
        uNominalHistory(i, k) = uNominal;

        [uSafe, diagnostics] = distributed_rcis_filter( ...
            q, uNominal, models{i}, envelopes{i}, ...
            predecessorVelocityLower, cfg1, cfg2);

        recursiveFeasible(i, k) = diagnostics.recursiveFeasible;
        feasibleCount(i, k) = diagnostics.feasibleCount;
        filterActive(i, k) = diagnostics.filterActive;

        if useSafetyFilter
            uChosen = uSafe;
            prediction = diagnostics.filtered.prediction;
            beta = diagnostics.filtered.beta;
            certificateMargin(i, k) = ...
                diagnostics.filtered.minimumMargin;
        else
            uChosen = uNominal;
            prediction = diagnostics.nominal.prediction;
            beta = diagnostics.nominal.beta;
            certificateMargin(i, k) = ...
                diagnostics.nominal.minimumMargin;
            filterActive(i, k) = false;
        end

        u(i, k) = uChosen;
        q(1) = uChosen;
        xNext(:, i) = vehicle_step_true(q, cfg1, i);
        predictionRatio(:, i, k) = ...
            abs(xNext(:, i) - prediction) ./ beta;

        predecessorVelocityLower = prediction(2) - beta(2);
    end

    x(:, :, k + 1) = xNext;
    actualBarrier(:, k + 1) = evaluate_actual_barrier( ...
        xNext, leader.velocity(k + 1), cfg2);
end

stateViolation = ...
    x(1, :, :) < cfg2.rcis.eMin - cfg2.validation.tolerance ...
    | x(1, :, :) > cfg2.rcis.eMax + cfg2.validation.tolerance ...
    | x(2, :, :) < cfg2.rcis.vMin - cfg2.validation.tolerance ...
    | x(2, :, :) > cfg2.rcis.vMax + cfg2.validation.tolerance;
inputViolation = ...
    u < cfg1.input.umin - cfg2.validation.tolerance ...
    | u > cfg1.input.umax + cfg2.validation.tolerance;

result.method = methodName;
result.x = x;
result.u = u;
result.uNominal = uNominalHistory;
result.disturbance = disturbance;
result.recursiveFeasible = recursiveFeasible;
result.filterActive = filterActive;
result.feasibleCount = feasibleCount;
result.certificateMargin = certificateMargin;
result.predictionRatio = predictionRatio;
result.actualBarrier = actualBarrier;
result.stateViolationCount = nnz(stateViolation);
result.inputViolationCount = nnz(inputViolation);
result.barrierViolationCount = nnz( ...
    actualBarrier < -cfg2.validation.tolerance);
end

function barrier = evaluate_actual_barrier(x, leaderVelocity, cfg2)
%EVALUATE_ACTUAL_BARRIER Braking-distance safety value for all agents.

N = size(x, 2);
barrier = zeros(N, 1);

for i = 1:N
    if i == 1
        predecessorVelocity = leaderVelocity;
    else
        predecessorVelocity = x(2, i - 1);
    end

    closingVelocity = max(x(2, i) - predecessorVelocity, 0);
    barrier(i) = cfg2.rcis.eMax - x(1, i) ...
        - closingVelocity^2 / (2 * cfg2.rcis.relativeBraking);
end
end
