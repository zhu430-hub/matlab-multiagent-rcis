function envelope = build_lifted_envelope(model, cfg, agentIndex, nGrid)
%BUILD_LIFTED_ENVELOPE Uniform deterministic one-step error certificate.

qGrid = create_tensor_grid(cfg.range.lower, cfg.range.upper, nGrid);
xNextTrue = vehicle_step_true(qGrid, cfg, agentIndex);
prediction = model.M * lifted_features(qGrid);
noiselessResidual = xNextTrue - prediction;

gridSpacing = 2 / (nGrid - 1);
epsilonCover = 0.5 * sqrt(cfg.dim.q) * gridSpacing;
lipschitz = lifted_residual_lipschitz_bound(model, cfg, agentIndex);
etaNoise = lifted_measurement_noise_support(model, cfg);
sampleMaximum = max(abs(noiselessResidual), [], 2);

envelope.beta = sampleMaximum + lipschitz * epsilonCover + etaNoise;
envelope.sampleMaximum = sampleMaximum;
envelope.lipschitz = lipschitz;
envelope.epsilonCover = epsilonCover;
envelope.etaNoise = etaNoise;
envelope.nCalibration = size(qGrid, 2);
end
