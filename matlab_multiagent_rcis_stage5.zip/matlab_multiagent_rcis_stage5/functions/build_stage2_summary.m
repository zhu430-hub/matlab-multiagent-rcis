function [methodSummary, agentSummary] = build_stage2_summary( ...
    nominal, safe, cfg1)
%BUILD_STAGE2_SUMMARY Construct method-level and safe-agent tables.

results = {nominal, safe};
method = strings(2, 1);
recursiveFeasibilityRate = zeros(2, 1);
filterActivationRate = zeros(2, 1);
stateConstraintViolations = zeros(2, 1);
inputConstraintViolations = zeros(2, 1);
barrierViolations = zeros(2, 1);
minCertifiedMargin = zeros(2, 1);
minActualBarrier = zeros(2, 1);
maxPredictionRatio = zeros(2, 1);
minSpacingError = zeros(2, 1);
maxSpacingError = zeros(2, 1);
minVelocity = zeros(2, 1);
maxVelocity = zeros(2, 1);
minInput = zeros(2, 1);
maxInput = zeros(2, 1);

for k = 1:2
    item = results{k};
    method(k) = string(item.method);
    recursiveFeasibilityRate(k) = mean(item.recursiveFeasible(:));
    filterActivationRate(k) = mean(item.filterActive(:));
    stateConstraintViolations(k) = item.stateViolationCount;
    inputConstraintViolations(k) = item.inputViolationCount;
    barrierViolations(k) = item.barrierViolationCount;
    minCertifiedMargin(k) = min(item.certificateMargin(:));
    minActualBarrier(k) = min(item.actualBarrier(:));
    maxPredictionRatio(k) = max(item.predictionRatio(:));
    minSpacingError(k) = min(item.x(1, :, :), [], 'all');
    maxSpacingError(k) = max(item.x(1, :, :), [], 'all');
    minVelocity(k) = min(item.x(2, :, :), [], 'all');
    maxVelocity(k) = max(item.x(2, :, :), [], 'all');
    minInput(k) = min(item.u(:));
    maxInput(k) = max(item.u(:));
end

methodSummary = table( ...
    method, recursiveFeasibilityRate, filterActivationRate, ...
    stateConstraintViolations, inputConstraintViolations, ...
    barrierViolations, minCertifiedMargin, minActualBarrier, ...
    maxPredictionRatio, minSpacingError, maxSpacingError, ...
    minVelocity, maxVelocity, minInput, maxInput);

agent = (1:cfg1.N).';
agentRecursiveFeasibilityRate = zeros(cfg1.N, 1);
agentFilterActivationRate = zeros(cfg1.N, 1);
agentMinCertificateMargin = zeros(cfg1.N, 1);
agentMinBarrier = zeros(cfg1.N, 1);
agentMaxPredictionRatio = zeros(cfg1.N, 1);
agentMaxSpacingError = zeros(cfg1.N, 1);

for i = 1:cfg1.N
    agentRecursiveFeasibilityRate(i) = ...
        mean(safe.recursiveFeasible(i, :));
    agentFilterActivationRate(i) = mean(safe.filterActive(i, :));
    agentMinCertificateMargin(i) = ...
        min(safe.certificateMargin(i, :));
    agentMinBarrier(i) = min(safe.actualBarrier(i, :));
    agentMaxPredictionRatio(i) = max( ...
        safe.predictionRatio(:, i, :), [], 'all');
    agentMaxSpacingError(i) = max(safe.x(1, i, :), [], 'all');
end

agentSummary = table( ...
    agent, agentRecursiveFeasibilityRate, agentFilterActivationRate, ...
    agentMinCertificateMargin, agentMinBarrier, ...
    agentMaxPredictionRatio, agentMaxSpacingError);
end
