function [trialTable, scenarioTable] = build_stage4_summary(records)
%BUILD_STAGE4_SUMMARY Convert trial records to detailed and aggregate tables.

n = numel(records);
scenario = strings(n, 1);
method = strings(n, 1);
success = false(n, 1);
recursiveFeasibilityRate = nan(n, 1);
filterActivationRate = nan(n, 1);
minimumCertificateMargin = nan(n, 1);
ellipsoidViolations = zeros(n, 1);
certificateEscapes = zeros(n, 1);
leaderContractViolations = zeros(n, 1);
maximumResidualRatio = zeros(n, 1);

for i = 1:n
    scenario(i) = records{i}.scenario;
    if records{i}.useFilter
        method(i) = "Distributed DD-RCIS";
    else
        method(i) = "Nominal";
    end
    success(i) = records{i}.success;
    recursiveFeasibilityRate(i) = records{i}.recursiveFeasibilityRate;
    filterActivationRate(i) = records{i}.filterActivationRate;
    minimumCertificateMargin(i) = records{i}.minimumCertificateMargin;
    ellipsoidViolations(i) = records{i}.ellipsoidViolations;
    certificateEscapes(i) = records{i}.certificateEscapes;
    leaderContractViolations(i) = ...
        records{i}.leaderContractViolations;
    maximumResidualRatio(i) = records{i}.maximumResidualRatio;
end

trialTable = table(scenario, method, success, ...
    recursiveFeasibilityRate, filterActivationRate, ...
    minimumCertificateMargin, ellipsoidViolations, ...
    certificateEscapes, leaderContractViolations, ...
    maximumResidualRatio);

[groups, scenarioName, methodName] = findgroups(scenario, method);
successRate = splitapply(@mean, double(success), groups);
meanRecursiveFeasibility = splitapply( ...
    @mean, recursiveFeasibilityRate, groups);
meanFilterActivation = splitapply(@mean, filterActivationRate, groups);
worstCertificateMargin = splitapply( ...
    @min, minimumCertificateMargin, groups);
totalEllipsoidViolations = splitapply(@sum, ellipsoidViolations, groups);
totalCertificateEscapes = splitapply(@sum, certificateEscapes, groups);
totalLeaderContractViolations = splitapply( ...
    @sum, leaderContractViolations, groups);
worstResidualRatio = splitapply(@max, maximumResidualRatio, groups);
scenarioTable = table(scenarioName, methodName, successRate, ...
    meanRecursiveFeasibility, meanFilterActivation, ...
    worstCertificateMargin, totalEllipsoidViolations, ...
    totalCertificateEscapes, totalLeaderContractViolations, ...
    worstResidualRatio);
end
