function xNext = vehicle_step_mismatch(q, drag, Ts)
%VEHICLE_STEP_MISMATCH Simulation plant with a specified drag coefficient.

u = q(1, :);
e = q(2, :);
v = q(3, :);
vRef = q(4, :);
d = q(5, :);
acceleration = u - drag .* v .* abs(v) + d;

xNext = [ ...
    e + Ts * (v - vRef) + 0.5 * Ts^2 * acceleration; ...
    v + Ts * acceleration];
end
