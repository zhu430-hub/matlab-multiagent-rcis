clear;
clc;
close all;
set(groot, 'defaultFigureVisible', 'off');

projectRoot = fileparts(mfilename('fullpath'));
addpath(fullfile(projectRoot, 'functions'));
cfg1 = config_stage1(projectRoot);
cfg3 = config_stage3(cfg1, projectRoot);
cfg4 = config_stage4(cfg1, cfg3, projectRoot);
rng(cfg1.randomSeed + 400, 'twister');

fprintf('Multi-agent data-driven RCIS experiment: Stage 4\n');
fprintf('Scenarios: %d, trials/scenario: %d, horizon: %.1f s\n', ...
    numel(cfg4.scenario), cfg4.nTrials, cfg4.Tfinal);

models = cell(cfg1.N, 1);
envelopes = cell(cfg1.N, 1);
for i = 1:cfg1.N
    data = collect_training_data(cfg1, i);
    models{i} = fit_lifted_predictor(data);
    envelopes{i} = build_lifted_envelope( ...
        models{i}, cfg1, i, cfg3.envelope.nGridPerDimension);
end

nRecords = 2 * numel(cfg4.scenario) * cfg4.nTrials;
records = cell(nRecords, 1);
recordIndex = 0;
for s = 1:numel(cfg4.scenario)
    fprintf('Scenario %s ...\n', cfg4.scenario(s).name);
    for trial = 1:cfg4.nTrials
        for useFilter = [false, true]
            recordIndex = recordIndex + 1;
            records{recordIndex} = run_stage4_trial( ...
                useFilter, cfg4.scenario(s), trial, ...
                models, envelopes, cfg1, cfg3, cfg4);
        end
    end
end

[trialTable, scenarioTable] = build_stage4_summary(records);
if ~exist(cfg4.resultsDir, 'dir')
    mkdir(cfg4.resultsDir);
end
save(fullfile(cfg4.resultsDir, 'stage4_results.mat'), ...
    'cfg1', 'cfg3', 'cfg4', 'models', 'envelopes', ...
    'records', 'trialTable', 'scenarioTable');
writetable(trialTable, fullfile(cfg4.resultsDir, ...
    'stage4_trial_summary.csv'));
writetable(scenarioTable, fullfile(cfg4.resultsDir, ...
    'stage4_scenario_summary.csv'));

certifiedSafe = scenarioTable.scenarioName == "Certified" ...
    & scenarioTable.methodName == "Distributed DD-RCIS";
assert(sum(certifiedSafe) == 1, ...
    'The certified safe summary row is missing.');
assert(scenarioTable.successRate(certifiedSafe) == 1, ...
    'A certified-condition DD-RCIS trial failed.');
assert(scenarioTable.meanRecursiveFeasibility(certifiedSafe) == 1, ...
    'The certified-condition online input set became empty.');
assert(scenarioTable.totalCertificateEscapes(certifiedSafe) == 0, ...
    'A certified-condition successor escaped its transmitted interval.');
assert(scenarioTable.totalLeaderContractViolations(certifiedSafe) == 0, ...
    'The certified-condition leader violated its declared contract.');
assert(scenarioTable.worstResidualRatio(certifiedSafe) <= ...
    1 + cfg4.validation.tolerance, ...
    'The certified-condition one-step residual envelope was exceeded.');

plot_stage4_results(scenarioTable, cfg4);

fprintf('\nStage 4 completed successfully.\n');
disp(scenarioTable);
