clear;
clc;
close all;
set(groot, 'defaultFigureVisible', 'off');

projectRoot = fileparts(mfilename('fullpath'));
addpath(fullfile(projectRoot, 'functions'));

cfg1 = config_stage1(projectRoot);
cfg2 = config_stage2(cfg1, projectRoot);
rng(cfg1.randomSeed, 'twister');

fprintf('Multi-agent data-driven RCIS experiment: Stage 2\n');
fprintf('Agents: %d, horizon: %.1f s, input candidates: %d\n', ...
    cfg1.N, cfg2.Tfinal, numel(cfg2.filter.uGrid));

models = cell(cfg1.N, 1);
envelopes = cell(cfg1.N, 1);

for i = 1:cfg1.N
    trainingData = collect_training_data(cfg1, i);
    models{i} = fit_local_predictor(trainingData, cfg1);
    envelopes{i} = build_calibration_envelope(models{i}, cfg1, i);
end

leader = build_leader_profile(cfg1, cfg2);
nominal = run_stage2_method( ...
    'Nominal', models, envelopes, leader, cfg1, cfg2);
safe = run_stage2_method( ...
    'Distributed DD-RCIS', models, envelopes, leader, cfg1, cfg2);

[methodSummary, agentSummary] = build_stage2_summary( ...
    nominal, safe, cfg1);

if ~exist(cfg2.resultsDir, 'dir')
    mkdir(cfg2.resultsDir);
end

save(fullfile(cfg2.resultsDir, 'stage2_results.mat'), ...
    'cfg1', 'cfg2', 'models', 'envelopes', 'leader', ...
    'nominal', 'safe', 'methodSummary', 'agentSummary');
writetable(methodSummary, fullfile(cfg2.resultsDir, ...
    'stage2_method_summary.csv'));
writetable(agentSummary, fullfile(cfg2.resultsDir, ...
    'stage2_agent_summary.csv'));

plot_stage2_results(nominal, safe, leader, cfg1, cfg2);

assert(all(safe.recursiveFeasible(:)), ...
    'The distributed RCIS input set became empty.');
assert(safe.stateViolationCount == 0, ...
    'The distributed DD-RCIS trajectory violated a hard state constraint.');
assert(safe.inputViolationCount == 0, ...
    'The distributed DD-RCIS trajectory violated a hard input constraint.');
assert(safe.barrierViolationCount == 0, ...
    'The distributed DD-RCIS trajectory violated the braking barrier.');
assert(min(safe.certificateMargin(:)) >= -cfg2.validation.tolerance, ...
    'A selected input has a negative robust successor certificate.');
assert(max(safe.predictionRatio(:)) <= 1 + cfg2.validation.tolerance, ...
    'A closed-loop successor escaped the Stage 1 error envelope.');

fprintf('\nStage 2 completed successfully.\n');
fprintf('Safe recursive-feasibility rate: %.2f%%\n', ...
    100 * mean(safe.recursiveFeasible(:)));
fprintf('Safe filter activation rate: %.2f%%\n', ...
    100 * mean(safe.filterActive(:)));
fprintf('Safe state/input/barrier violations: %d / %d / %d\n', ...
    safe.stateViolationCount, safe.inputViolationCount, ...
    safe.barrierViolationCount);
fprintf('Nominal state/barrier violations: %d / %d\n', ...
    nominal.stateViolationCount, nominal.barrierViolationCount);
fprintf('Minimum safe certificate margin: %.6e\n', ...
    min(safe.certificateMargin(:)));
fprintf('Maximum closed-loop residual ratio: %.6f\n', ...
    max(safe.predictionRatio(:)));
