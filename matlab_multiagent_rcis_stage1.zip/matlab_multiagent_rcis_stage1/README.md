# Multi-Agent Data-Driven RCIS: Stage 1

This MATLAB project implements the first reproducible experiment for the
multi-agent data-driven RCIS paper:

1. a heterogeneous five-vehicle platoon;
2. bounded measurement noise and measured exogenous signals;
3. local one-step data collection;
4. the fixed minimum-norm data-driven predictor
   `x_next_hat = X1 * G * w`;
5. a deterministic residual envelope containing calibration coverage,
   a residual Lipschitz bound, and measurement-noise support;
6. independent held-out validation, assertions, figures, and a CSV summary.

No optimization toolbox, Statistics and Machine Learning Toolbox, or YALMIP
is required for Stage 1. MATLAB R2020a or newer is recommended.

## Run

Open MATLAB in this folder and execute:

```matlab
run_stage1_data_validation
```

The repository also includes a GitHub Actions workflow that runs the same
script using the official `matlab-actions/setup-matlab` and
`matlab-actions/run-command` actions. Workflow artifacts are retained for one
day.

Generated files are written to `results/`:

- `stage1_results.mat`
- `stage1_summary.csv`
- `fig_stage1_residual_ratio.png`
- `fig_stage1_data_quality.png`

## Interpretation

For every tested residual component, the normalized ratio

```matlab
abs(x_next_measured - x_next_predicted) ./ beta
```

must be no larger than one, up to numerical tolerance. The script stops with
an error if the data matrix is rank deficient or if the certified envelope is
violated.

The true vehicle dynamics and its derivative are used only by the simulation
plant and to supply a known residual Lipschitz upper bound. The data-driven
predictor itself uses only the sampled matrices `W` and `X1`.

## Next stage

Stage 2 will add the offline homothetic RCIS and affine edge-responsibility
contract SOCP. That stage will require YALMIP and a conic solver such as
MOSEK, GUROBI, or SeDuMi.
