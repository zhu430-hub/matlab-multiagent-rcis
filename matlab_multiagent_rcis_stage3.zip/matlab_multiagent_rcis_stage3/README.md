# Multi-Agent Data-Driven RCIS: Stages 1-3

This MATLAB project implements the first three reproducible experiments for the
multi-agent data-driven RCIS paper.

Stage 1 provides:

1. a heterogeneous five-vehicle platoon;
2. bounded measurement noise and measured exogenous signals;
3. local one-step data collection;
4. the fixed minimum-norm data-driven predictor
   `x_next_hat = X1 * G * w`;
5. a deterministic residual envelope containing calibration coverage,
   a residual Lipschitz bound, and measurement-noise support;
6. independent held-out validation, assertions, figures, and a CSV summary.

Stage 2 adds:

1. predecessor-following coupling for five heterogeneous vehicles;
2. a front-to-back one-hop certificate message;
3. a distributed data-driven RCIS safety filter;
4. hard input/state and braking-distance constraints;
5. closed-loop recursive-feasibility checks against a nominal baseline.

Stage 3 adds:

1. a lifted data-driven predictor with the additional feature `v*abs(v)`;
2. deterministic propagation of bounded measurement noise through the lift;
3. a robust ellipsoid in spacing-error/relative-velocity coordinates;
4. an offline tensor-grid existence test for a robust successor input;
5. a direct affine-versus-lifted model comparison for all five agents.

No optimization toolbox, Statistics and Machine Learning Toolbox, or YALMIP
is required. MATLAB R2020a or newer is recommended.

## Run

Open MATLAB in this folder and execute:

```matlab
run_stage1_data_validation
```

Run the coupled distributed experiment with:

```matlab
run_stage2_distributed_rcis
```

Run the offline Stage 3 certificate with:

```matlab
run_stage3_offline_rcis
```

The repository also includes a GitHub Actions workflow that runs the same
script using the official `matlab-actions/setup-matlab` and
`matlab-actions/run-command` actions. Workflow artifacts are retained for one
day.

Generated files are written to `results/`:

- `stage1_results.mat`
- `stage1_summary.csv`
- `fig_stage1_residual_ratio.png`
- `fig_stage1_data_quality.png`

Stage 2 writes the following files to `results_stage2/`:

- `stage2_results.mat`
- `stage2_method_summary.csv`
- `stage2_agent_summary.csv`
- `fig_stage2_distributed_closed_loop.png`
- `fig_stage2_method_comparison.png`

Stage 3 writes the following files to `results_stage3/`:

- `stage3_results.mat`
- `stage3_grid_summary.csv`
- `fig_stage3_grid_certificate.png`

## Interpretation

For every tested residual component, the normalized ratio

```matlab
abs(x_next_measured - x_next_predicted) ./ beta
```

must be no larger than one, up to numerical tolerance. The script stops with
an error if the data matrix is rank deficient or if the certified envelope is
violated.

The true vehicle dynamics and its derivative are used only by the simulation
plant and to supply a known residual Lipschitz upper bound. The data-driven
predictor itself uses only the sampled matrices `W` and `X1`.

The Stage 2 filter uses a dense scalar input grid so that the reproducible
experiment remains independent of commercial optimization software. The next
stage can replace this online search with the paper's offline homothetic RCIS
and edge-responsibility contract program.

Stage 3 deliberately distinguishes an offline tensor-grid certificate from a
continuous-state theorem. Every included grid state must have at least one
input whose complete interval-valued successor lies inside the same
ellipsoid. The four vertices of the successor rectangle are checked because
the ellipsoidal quadratic form is convex. A later interval subdivision or
Lipschitz cell argument is still required to promote this result to a
continuous-domain proof.
