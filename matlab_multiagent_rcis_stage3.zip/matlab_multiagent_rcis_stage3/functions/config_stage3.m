function cfg3 = config_stage3(cfg1, projectRoot)
%CONFIG_STAGE3 Offline grid certificate for a coupled robust ellipsoidal set.

cfg3.operating.eCenter = -0.50;
cfg3.operating.vMin = 2.80;
cfg3.operating.vMax = 6.20;
cfg3.operating.vRefMin = 3.50;
cfg3.operating.vRefMax = 5.50;
cfg3.operating.aRefMin = -0.50;
cfg3.operating.aRefMax = 0.25;

% The nominal relative double-integrator has poles 0.75 and 0.85 under
% u_rel = -K*[e-eCenter; v-vRef].  P solves Acl'*P*Acl-P=-I.
cfg3.ellipsoid.feedbackGain = [3.75, 3.8125];
cfg3.ellipsoid.rho = 10.0;
A = [1, cfg1.Ts; 0, 1];
B = [0.5 * cfg1.Ts^2; cfg1.Ts];
Acl = A - B * cfg3.ellipsoid.feedbackGain;
identity2 = eye(2);
P = reshape((eye(4) - kron(Acl.', Acl.')) \ identity2(:), 2, 2);
P = 0.5 * (P + P.');
cfg3.ellipsoid.P = P / sqrt(det(P));

inverseP = inv(cfg3.ellipsoid.P);
cfg3.grid.errorRadius = sqrt( ...
    cfg3.ellipsoid.rho * inverseP(1, 1));
cfg3.grid.relativeVelocityRadius = sqrt( ...
    cfg3.ellipsoid.rho * inverseP(2, 2));
cfg3.grid.nError = 31;
cfg3.grid.nRelativeVelocity = 31;
cfg3.grid.nReferenceVelocity = 13;
cfg3.grid.disturbance = [-0.15, 0, 0.15];

cfg3.input.uGrid = linspace( ...
    cfg1.input.umin, cfg1.input.umax, 351);
cfg3.computation.stateChunk = 256;
cfg3.envelope.nGridPerDimension = 7;
cfg3.validation.tolerance = 1e-9;
cfg3.resultsDir = fullfile(projectRoot, 'results_stage3');
end
