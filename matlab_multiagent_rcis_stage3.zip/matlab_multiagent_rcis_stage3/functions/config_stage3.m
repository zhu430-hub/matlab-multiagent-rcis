function cfg3 = config_stage3(cfg1, projectRoot)
%CONFIG_STAGE3 Offline grid certificate for a coupled robust ellipsoidal set.

cfg3.operating.eCenter = -0.50;
cfg3.operating.vMin = 2.80;
cfg3.operating.vMax = 6.20;
cfg3.operating.vRefMin = 3.50;
cfg3.operating.vRefMax = 5.50;
cfg3.operating.aRefMin = -0.50;
cfg3.operating.aRefMax = 0.25;

% The nominal relative double-integrator has poles 0.75 and 0.85 under
% u_rel = -K*[e-eCenter; v-vRef].  P solves Acl'*P*Acl-P=-I.
cfg3.ellipsoid.feedbackGain = [3.75, 3.8125];
cfg3.ellipsoid.rho = 10.0;
A = [1, cfg1.Ts; 0, 1];
B = [0.5 * cfg1.Ts^2; cfg1.Ts];
Acl = A - B * cfg3.ellipsoid.feedbackGain;
identity2 = eye(2);
% Solve the symmetric discrete Lyapunov equation explicitly.  This avoids
% depending on a vec/kron ordering convention or a toolbox implementation.
a = Acl(1, 1);
b = Acl(1, 2);
c = Acl(2, 1);
d = Acl(2, 2);
lyapunovMatrix = [ ...
    1 - a^2,      -2 * a * c,      -c^2; ...
    -a * b, 1 - a * d - b * c,      -c * d; ...
    -b^2,         -2 * b * d, 1 - d^2];
solution = lyapunovMatrix \ [identity2(1, 1); 0; identity2(2, 2)];
P = [solution(1), solution(2); solution(2), solution(3)];
cfg3.ellipsoid.P = P / sqrt(det(P));

inverseP = inv(cfg3.ellipsoid.P);
cfg3.grid.errorRadius = sqrt( ...
    cfg3.ellipsoid.rho * inverseP(1, 1));
cfg3.grid.relativeVelocityRadius = sqrt( ...
    cfg3.ellipsoid.rho * inverseP(2, 2));
cfg3.grid.nError = 31;
cfg3.grid.nRelativeVelocity = 31;
cfg3.grid.nReferenceVelocity = 13;
cfg3.grid.disturbance = [-0.15, 0, 0.15];

cfg3.input.uGrid = linspace( ...
    cfg1.input.umin, cfg1.input.umax, 351);
cfg3.computation.stateChunk = 256;
cfg3.envelope.nGridPerDimension = 7;
cfg3.validation.tolerance = 1e-9;
cfg3.resultsDir = fullfile(projectRoot, 'results_stage3');
end
